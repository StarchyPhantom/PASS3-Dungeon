﻿//
using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Animation2D;
using Helper;

namespace PASS3Game
{
	/// <summary>
	/// This is the main type for your game.
	/// </summary>
	public class Game1 : Game
	{
		const byte MENU = 0;
		const byte GAME = 1;
		const byte ENDGAME = 2;

		const byte DOWN = 0;
		const byte LEFT = 1;
		const byte RIGHT = 2;
		const byte UP = 3;

		const float BASE_SPEED = 2;
		const float BASE_BULLET_SPEED = 3;

		const float HIDE_OBJECTS_LOC = -400;

		const int BASE_FIRE_RATE = 500;

		const int BORDER_OFFSET = 20;

		private GraphicsDeviceManager graphics;
		private SpriteBatch spriteBatch;

		//height & width of the screen
		int screenWidth;
		int screenHeight;

		KeyboardState kb;

		MouseState mouse;

		Texture2D[] mainCharJImg = new Texture2D[4];

		Texture2D metalBulletImg;
		Texture2D batEnemyImg;

		Vector2[] playerBulletsLoc = new Vector2[100];
		Vector2[] batEnemiesLoc = new Vector2[20];

		Vector2 mainCharLoc;
		Vector2 mainCharCenterLoc;

		Rectangle[] playerBulletsRec = new Rectangle[100];
		Rectangle[] batEnemiesRec = new Rectangle[20];

		Rectangle mainCharRec;

		Animation[] mainCharJAnim = new Animation[4];
		Animation batEnemyAnim;

		Timer playerFireRateTimer;

		byte gameState = 0;

		byte charDirection = 0;

		int playerBulletsCount = 0;

		float currentMaxSpeed = BASE_SPEED;
		float maxDiagonalSpeed = (float)Math.Sqrt(BASE_SPEED);

		float[] playerBulletSpeedX = new float[100];
		float[] playerBulletSpeedY = new float[100];
		float playerBulletAngle;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
			// TODO: Add your initialization logic here

			IsMouseVisible = true;

			//get the width and height of the window
			screenWidth = graphics.GraphicsDevice.Viewport.Width;
			screenHeight = graphics.GraphicsDevice.Viewport.Height;

			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			// Create a new SpriteBatch, which can be used to draw textures.
			spriteBatch = new SpriteBatch(GraphicsDevice);

			// TODO: use this.Content to load your game content here
			
			mainCharJImg[DOWN] = Content.Load<Texture2D>("Animations/CharacterJDOWN");
			mainCharJImg[LEFT] = Content.Load<Texture2D>("Animations/CharacterJLEFT");
			mainCharJImg[RIGHT] = Content.Load<Texture2D>("Animations/CharacterJRIGHT");
			mainCharJImg[UP] = Content.Load<Texture2D>("Animations/CharacterJUP");

			metalBulletImg = Content.Load<Texture2D>("Sprites/MetalBullet");

			batEnemyImg = Content.Load<Texture2D>("Animations/BatEnemy");

			mainCharLoc = new Vector2(0, 0);
			mainCharCenterLoc = new Vector2(0, 0);

			for (int i = 0; i < 100 ; i++)
			{
				playerBulletsLoc[i] = new Vector2(HIDE_OBJECTS_LOC, HIDE_OBJECTS_LOC);
				playerBulletsRec[i] = new Rectangle((int)playerBulletsLoc[i].X, (int)playerBulletsLoc[i].Y, (int)(metalBulletImg.Width * 0.5), (int)(metalBulletImg.Height * 0.5));
				playerBulletSpeedX[i] = 0;
				playerBulletSpeedY[i] = 0;
			}

			/*for (int i = 0; i < 20; i++)
			{
				batEnemiesLoc[i] = new Vector2(HIDE_OBJECTS_LOC, HIDE_OBJECTS_LOC);
				batEnemiesRec[i] = new Rectangle((int)playerBulletsLoc[i].X, (int)playerBulletsLoc[i].Y, (int)(metalBulletImg.Width * 0.5), (int)(metalBulletImg.Height * 0.5));
			}*/

			batEnemiesLoc[0] = new Vector2(0, 0);
			batEnemiesRec[0] = new Rectangle((int)batEnemiesLoc[0].X, (int)batEnemiesLoc[0].Y, (int)(batEnemyImg.Width * 0.5), (int)(batEnemyImg.Height * 0.5));

			mainCharRec = new Rectangle((int)mainCharLoc.X, (int)mainCharLoc.Y, (int)(mainCharJImg[DOWN].Width * 0.2), (int)(mainCharJImg[DOWN].Height * 0.2));

			mainCharJAnim[DOWN] = new Animation(mainCharJImg[DOWN], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[LEFT] = new Animation(mainCharJImg[LEFT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[RIGHT] = new Animation(mainCharJImg[RIGHT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[UP] = new Animation(mainCharJImg[UP], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);

			batEnemyAnim = new Animation(batEnemyImg, 4, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 1, true);

			playerFireRateTimer = new Timer(BASE_FIRE_RATE, true);
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// game-specific content.
		/// </summary>
		protected override void UnloadContent()
		{
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			kb = Keyboard.GetState();
			mouse = Mouse.GetState();

			// TODO: Add your update logic here
			switch (gameState)
			{
				case MENU:
					UpdateMenu();
					break;
				case GAME:
					UpdateGame(gameTime);
					break;
				case ENDGAME:
					UpdateEndGame();
					break;
			}

			base.Update(gameTime);
		}

		private void UpdateMenu()
		{
			gameState = GAME;
		}

		private void UpdateGame(GameTime gameTime)
		{
			playerFireRateTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			mainCharJAnim[charDirection].Update(gameTime); //maxDiagonalSpeed = (float)Math.Sqrt(BASE_SPEED);
			batEnemyAnim.Update(gameTime);


			//Move and face a direction depending on input
			if ((kb.IsKeyDown(Keys.W)|| kb.IsKeyDown(Keys.S)) && (kb.IsKeyDown(Keys.A) || kb.IsKeyDown(Keys.D)))
			{
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += maxDiagonalSpeed;
				}
			}
			else
			{
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += currentMaxSpeed;
				}

				mainCharJAnim[charDirection].isAnimating = true;
			}

			mainCharCenterLoc.X = (mainCharLoc.X + ((mainCharJImg[charDirection].Width / 4) * 0.5f * 0.5f));
			mainCharCenterLoc.Y = (mainCharLoc.Y + (mainCharJImg[charDirection].Height * 0.5f * 0.5f));

			for (int i = 0; i < 4; i++)
			{
				mainCharJAnim[i].destRec.X = (int)mainCharLoc.X;
				mainCharJAnim[i].destRec.Y = (int)mainCharLoc.Y;
			}

			if (mouse.LeftButton == ButtonState.Pressed && playerFireRateTimer.IsFinished())
			{
				playerBulletAngle = (float)Math.Atan((mouse.Y - mainCharCenterLoc.Y) / ((mouse.X - mainCharCenterLoc.X)));
				
				if (mouse.X < mainCharCenterLoc.X)
				{
					playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Cos(playerBulletAngle);
					playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Sin(playerBulletAngle);
				}
				else
				{
					playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Cos(playerBulletAngle);
					playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Sin(playerBulletAngle);
				}
				
				playerBulletsLoc[playerBulletsCount] = mainCharCenterLoc;
				playerBulletsCount++;

				playerFireRateTimer.ResetTimer(true);
			}

			for (int i = 0; i <= playerBulletsCount; i++)
			{
				playerBulletsLoc[i].X += playerBulletSpeedX[i];
				playerBulletsLoc[i].Y += playerBulletSpeedY[i];
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;
				
				if ((playerBulletsRec[i].X > screenWidth - BORDER_OFFSET || playerBulletsRec[i].X < BORDER_OFFSET || playerBulletsRec[i].Y > screenHeight - BORDER_OFFSET || playerBulletsRec[i].Y < BORDER_OFFSET) && playerBulletsRec[i].X != HIDE_OBJECTS_LOC)
				{
					for (int j = i; j <= playerBulletsCount; j++)
					{
						playerBulletSpeedX[j] = playerBulletSpeedX[j + 1];
						playerBulletSpeedY[j] = playerBulletSpeedY[j + 1];
						playerBulletsLoc[j].X = playerBulletsLoc[j + 1].X;
						playerBulletsLoc[j].Y = playerBulletsLoc[j + 1].Y;
					}

					playerBulletsCount--;
				}
			}
		}

		private void UpdateEndGame()
		{

		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.CornflowerBlue);

			// TODO: Add your drawing code here
			spriteBatch.Begin();
			switch (gameState)
			{
				case MENU:
					DrawMenu();
					break;
				case GAME:
					DrawGame();
					break;
				case ENDGAME:
					DrawEndGame();
					break;
			}
			spriteBatch.End();

			base.Draw(gameTime);
		}

		private void DrawMenu()
		{
			
		}

		private void DrawGame()
		{
			mainCharJAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
			batEnemyAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);

			for (int i = 0; i <= playerBulletsCount; i++)
			{
				spriteBatch.Draw(metalBulletImg, playerBulletsRec[i], Color.White);
			}
		}

		private void DrawEndGame()
		{

		}

		private void DoDiagonalSpeed()
		{

		}
	}
}
