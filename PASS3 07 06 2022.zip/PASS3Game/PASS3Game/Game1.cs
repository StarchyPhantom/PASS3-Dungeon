﻿//Author: Benjamin Huynh
//File Name: Game1.cs
//Project Name: PASS2
//Creation Date: May. 24, 2022
//Modified Date: June. 02, 2022
//Description: 
using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Animation2D;
using Helper;

namespace PASS3Game
{
	/// <summary>
	/// This is the main type for your game.
	/// </summary>
	public class Game1 : Game
	{
		const byte MENU = 0;
		const byte PREGAME = 1;
		const byte GAME = 2;
		const byte ENDGAME = 3;

		const byte DOWN = 0;
		const byte LEFT = 1;
		const byte RIGHT = 2;
		const byte UP = 3;

		const byte NO_ITEM = 0;
		const byte COFFEE = 1;

		const float BASE_SPEED = 2;
		const float BASE_BULLET_SPEED = 3;
		const float BASE_BAT_SPEED = 1.5f;

		const float HIDE_OBJECTS_LOCATION = -400;

		const int BASE_FIRE_RATE = 625;
		const int MAX_BULLETS = 100;

		const int BORDER_OFFSET = 50;

		const int UI_OFFSET = 150;
		const int UI_ICON_OFFSET = 10;

		const int MAX_BATS = 100;

		private GraphicsDeviceManager graphics;
		private SpriteBatch spriteBatch;

		//height & width of the screen
		int screenWidth;
		int screenHeight;

		static Random rng = new Random();

		//the keys pressed on the keyboard
		KeyboardState kb;

		//the state of the mouse
		MouseState mouse;
		MouseState prevMouse;

		SpriteFont gameFont;

		Texture2D[] mainCharJImg = new Texture2D[4];
		Texture2D[] randomRocksImg = new Texture2D[20];

		Texture2D heartImg;

		Texture2D floorBkImg;
		Texture2D wallBkImg;
		Texture2D blackPathImg;
		Texture2D downArrowImg;
		Texture2D rock1Img;
		Texture2D rock2Img;
		Texture2D rock3Img;

		Texture2D metalBulletImg;
		Texture2D batEnemyImg;
		Texture2D coffeeImg;

		Texture2D retryButtonImg;

		Vector2[] enemySpawnFloorsLoc = new Vector2[4];
		Vector2[] enemySpawnsLoc = new Vector2[4];
		Vector2[] playerBulletsLoc = new Vector2[100];
		Vector2[] batEnemiesLoc = new Vector2[MAX_BATS];
		Vector2[] batEnemiesCenterLoc = new Vector2[MAX_BATS];

		Vector2 hideObjectsLoc;
		Vector2 roomCharacterStartLoc;

		Vector2 floorBkLoc;
		Vector2 wallBkLoc;

		Vector2 downArrowLoc;

		Vector2 heartJLoc;
		Vector2 healthJLoc;

		Vector2 mainCharLoc;
		Vector2 mainCharCenterLoc;
		Vector2 UIItemLoc;
		Vector2 coffeeLoc;

		Vector2 retryButtonLoc;

		Rectangle[] enemySpawnFloorsRec = new Rectangle[4];
		Rectangle[] rocksRec = new Rectangle[20];
		Rectangle[] playerBulletsRec = new Rectangle[100];

		Rectangle floorBkRec;
		Rectangle wallBkRec;

		Rectangle downArrowRec;

		Rectangle mainCharRec;

		Rectangle heartJRec;

		Rectangle retryButtonRec;

		Animation[] mainCharJAnim = new Animation[4];
		Animation[] batEnemyAnim = new Animation[MAX_BATS];
		Animation UICoffeeAnim;
		Animation coffeeAnim;

		Timer playerFireRateTimer;
		Timer playerImmunityTimer;

		Timer batEnemiesSpawnTimer;

		Timer coffeeEffectTimer;

		byte gameState = 0;

		byte numRocks;
		byte charDirection = 0;
		byte currentPlayerItem = NO_ITEM;

		int currentRound = 1;

		int randomEnemySpawnDirection = 0;

		int playerJHealth = 5;
		int playerBulletsCount = 0;
		int totalEnemyCount= 0;
		int batEnemiesCount = 0;
		int batEnemiesToSpawn = 20;
		int batEnemiesSpawned = 0;

		float[] roomLayoutX = new float[5];
		float[] roomLayoutY = new float[5];
		float[] roomType1X;
		float[] roomType1Y;
		float[] roomType2X;
		float[] roomType2Y;

		float currentMaxSpeed = BASE_SPEED;
		float maxDiagonalSpeed = (float)Math.Sqrt(BASE_SPEED);

		float[] playerBulletSpeedX = new float[100];
		float[] playerBulletSpeedY = new float[100];
		float playerBulletAngle;

		float charDistFromRockX;
		float charDistFromRockY;

		bool isCoffeeInRoom = false;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
			// TODO: Add your initialization logic here

			graphics.PreferredBackBufferWidth = 768 + UI_OFFSET * 2;
			graphics.PreferredBackBufferHeight = 768;

			graphics.ApplyChanges();

			IsMouseVisible = true;

			//get the width and height of the window
			screenWidth = graphics.GraphicsDevice.Viewport.Width;
			screenHeight = graphics.GraphicsDevice.Viewport.Height;

			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			// Create a new SpriteBatch, which can be used to draw textures.
			spriteBatch = new SpriteBatch(GraphicsDevice);

			// TODO: use this.Content to load your game content here

			gameFont = Content.Load<SpriteFont>("Fonts/GameFont");

			blackPathImg = Content.Load<Texture2D>("Backgrounds/BlackPanel");
			floorBkImg = Content.Load<Texture2D>("Backgrounds/GreyWall");
			wallBkImg = Content.Load<Texture2D>("Backgrounds/BlueWall");
			downArrowImg = Content.Load<Texture2D>("Sprites/DownArrow");
			rock1Img = Content.Load<Texture2D>("Sprites/Stone1");
			rock2Img = Content.Load<Texture2D>("Sprites/Stone2");
			rock3Img = Content.Load<Texture2D>("Sprites/Stone3");

			heartImg = Content.Load<Texture2D>("Sprites/Heart");

			mainCharJImg[DOWN] = Content.Load<Texture2D>("Animations/CharacterJDOWN");
			mainCharJImg[LEFT] = Content.Load<Texture2D>("Animations/CharacterJLEFT");
			mainCharJImg[RIGHT] = Content.Load<Texture2D>("Animations/CharacterJRIGHT");
			mainCharJImg[UP] = Content.Load<Texture2D>("Animations/CharacterJUP");

			metalBulletImg = Content.Load<Texture2D>("Sprites/MetalBullet");
			batEnemyImg = Content.Load<Texture2D>("Animations/BatEnemy");
			coffeeImg = Content.Load<Texture2D>("Animations/Coffee");

			retryButtonImg = Content.Load<Texture2D>("Sprites/RetryButton");

			hideObjectsLoc = new Vector2(HIDE_OBJECTS_LOCATION, HIDE_OBJECTS_LOCATION);
			roomCharacterStartLoc = new Vector2(screenWidth / 2 - mainCharJImg[DOWN].Width / 2 / 2, screenHeight / 2 - mainCharJImg[DOWN].Height / 2 / 2);

			floorBkLoc = new Vector2(BORDER_OFFSET + UI_OFFSET, BORDER_OFFSET);
			wallBkLoc = new Vector2(UI_OFFSET, 0);

			downArrowLoc = new Vector2(screenWidth / 2 - downArrowImg.Width / 2, screenHeight / 1.5f);

			heartJLoc = new Vector2(UI_OFFSET / 2 - heartImg.Width/ 2, screenHeight / 4);
			healthJLoc = new Vector2(heartJLoc.X + heartImg.Width + UI_ICON_OFFSET, heartJLoc.Y);

			mainCharLoc = roomCharacterStartLoc;
			mainCharCenterLoc = new Vector2(BORDER_OFFSET, BORDER_OFFSET);

			UIItemLoc = new Vector2(UI_OFFSET / 2 - coffeeImg.Width / 2, screenHeight / 2);
			coffeeLoc = hideObjectsLoc;

			retryButtonLoc = new Vector2(screenWidth / 2 - retryButtonImg.Width / 2, screenHeight / 2 - retryButtonImg.Height / 2);

			enemySpawnFloorsLoc[DOWN] = new Vector2(screenWidth / 2 - BORDER_OFFSET / 2 * 3, screenHeight - BORDER_OFFSET);
			enemySpawnFloorsLoc[LEFT] = new Vector2(UI_OFFSET, screenHeight / 2 - BORDER_OFFSET / 2 * 3);
			enemySpawnFloorsLoc[RIGHT] = new Vector2(screenWidth - UI_OFFSET - BORDER_OFFSET, screenHeight / 2 - BORDER_OFFSET / 2 * 3);
			enemySpawnFloorsLoc[UP] = new Vector2(screenWidth / 2 - BORDER_OFFSET / 2 * 3, 0);

			enemySpawnsLoc[DOWN] = new Vector2(screenWidth / 2, screenHeight);
			enemySpawnsLoc[LEFT] = new Vector2(UI_OFFSET, screenHeight / 2);
			enemySpawnsLoc[RIGHT] = new Vector2(screenWidth - UI_OFFSET, screenHeight / 2);
			enemySpawnsLoc[UP] = new Vector2(screenWidth / 2, 0);

			for (int i = 0; i < MAX_BULLETS ; i++)
			{
				playerBulletsLoc[i] = hideObjectsLoc;
				playerBulletsRec[i] = new Rectangle((int)playerBulletsLoc[i].X, (int)playerBulletsLoc[i].Y, (int)(metalBulletImg.Width * 0.5), (int)(metalBulletImg.Height * 0.5));
				playerBulletSpeedX[i] = 0;
				playerBulletSpeedY[i] = 0;
			}

			for (int i = 0; i < MAX_BATS; i++)
			{
				batEnemiesLoc[i] = hideObjectsLoc;
				batEnemiesCenterLoc[i] = hideObjectsLoc;
				batEnemyAnim[i] = new Animation(batEnemyImg, 4, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, batEnemiesLoc[i], 1, true);
			}

			for (int i = 0; i < 20; i++)
			{
				rocksRec[i] = new Rectangle((int)HIDE_OBJECTS_LOCATION, (int)HIDE_OBJECTS_LOCATION, rock1Img.Width * 2, rock1Img.Height * 2);

			}

			floorBkRec = new Rectangle((int)floorBkLoc.X, (int)floorBkLoc.Y, screenWidth - (BORDER_OFFSET * 2) - UI_OFFSET * 2, screenHeight - (BORDER_OFFSET * 2));
			wallBkRec = new Rectangle((int)wallBkLoc.X, (int)wallBkLoc.Y, screenWidth - UI_OFFSET * 2, screenHeight);

			downArrowRec = new Rectangle((int)HIDE_OBJECTS_LOCATION, (int)HIDE_OBJECTS_LOCATION, downArrowImg.Width, downArrowImg.Height);

			heartJRec = new Rectangle((int)heartJLoc.X, (int)heartJLoc.Y, heartImg.Width, heartImg.Height);

			mainCharRec = new Rectangle((int)mainCharLoc.X, (int)mainCharLoc.Y, (int)(mainCharJImg[DOWN].Width * 0.2), (int)(mainCharJImg[DOWN].Height * 0.2));

			retryButtonRec = new Rectangle((int)retryButtonLoc.X, (int)retryButtonLoc.Y, retryButtonImg.Width, retryButtonImg.Height);

			enemySpawnFloorsRec[DOWN] = new Rectangle((int)enemySpawnFloorsLoc[DOWN].X, (int)enemySpawnFloorsLoc[DOWN].Y, BORDER_OFFSET * 3, BORDER_OFFSET);
			enemySpawnFloorsRec[LEFT] = new Rectangle((int)enemySpawnFloorsLoc[LEFT].X, (int)enemySpawnFloorsLoc[LEFT].Y, BORDER_OFFSET, BORDER_OFFSET * 3);
			enemySpawnFloorsRec[RIGHT] = new Rectangle((int)enemySpawnFloorsLoc[RIGHT].X, (int)enemySpawnFloorsLoc[RIGHT].Y, BORDER_OFFSET, BORDER_OFFSET * 3);
			enemySpawnFloorsRec[UP] = new Rectangle((int)enemySpawnFloorsLoc[UP].X, (int)enemySpawnFloorsLoc[UP].Y, BORDER_OFFSET * 3, BORDER_OFFSET);

			mainCharJAnim[DOWN] = new Animation(mainCharJImg[DOWN], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[LEFT] = new Animation(mainCharJImg[LEFT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[RIGHT] = new Animation(mainCharJImg[RIGHT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[UP] = new Animation(mainCharJImg[UP], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);

			UICoffeeAnim = new Animation(coffeeImg, 2, 1, 2, 0, 0, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 1, true);
			coffeeAnim = new Animation(coffeeImg, 2, 1, 2, 0, 0, Animation.ANIMATE_FOREVER, 10, coffeeLoc, 1, true);

			playerFireRateTimer = new Timer(BASE_FIRE_RATE, true);
			playerImmunityTimer = new Timer(3000, true);

			batEnemiesSpawnTimer = new Timer(rng.Next(500, 1501), true);

			coffeeEffectTimer = new Timer(10000, false);

			roomType1X = new float[] { UI_OFFSET + BORDER_OFFSET,
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 4),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 5),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 6)};
			roomType1Y = new float[] { BORDER_OFFSET,
									   BORDER_OFFSET + (rock1Img.Height * 2),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 2),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 4),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 5),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 6)};
			roomType2X = new float[] { UI_OFFSET + BORDER_OFFSET,
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 3),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 4),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 5),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 6)};
			roomType2Y = new float[] { screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2)};
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// game-specific content.
		/// </summary>
		protected override void UnloadContent()
		{
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			kb = Keyboard.GetState();
			prevMouse = mouse;
			mouse = Mouse.GetState();

			// TODO: Add your update logic here
			switch (gameState)
			{
				case MENU:
					UpdateMenu();
					break;
				case PREGAME:
					UpdatePregame();
					break;
				case GAME:
					UpdateGame(gameTime);
					break;
				case ENDGAME:
					UpdateEndGame();
					break;
			}

			base.Update(gameTime);
		}

		private void UpdateMenu()
		{
			gameState = PREGAME;
		}

		private void UpdatePregame()
		{
			currentRound = 1;
			playerJHealth = 5;
			currentMaxSpeed = BASE_SPEED;
			currentPlayerItem = NO_ITEM;
			coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
			coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			UICoffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
			UICoffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			coffeeEffectTimer.ResetTimer(false);
			isCoffeeInRoom = false;
			batEnemiesSpawned = 0;
			batEnemiesCount = 0;
			batEnemiesToSpawn = 20;

			for (int i = 0; i < MAX_BATS; i++)
			{
				batEnemiesLoc[i] = hideObjectsLoc;
				batEnemiesCenterLoc[i] = hideObjectsLoc;
				batEnemyAnim[i].destRec.X = (int)batEnemiesLoc[i].X;
				batEnemyAnim[i].destRec.Y = (int)batEnemiesLoc[i].Y;
			}

			for (int i = 0; i < MAX_BULLETS; i++)
			{
				playerBulletsLoc[i] = hideObjectsLoc;
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;
				playerBulletSpeedX[i] = 0;
				playerBulletSpeedY[i] = 0;
			}

			for (int i = 0; i < 20; i++)
			{
				rocksRec[i].X = (int)HIDE_OBJECTS_LOCATION;
				rocksRec[i].Y = (int)HIDE_OBJECTS_LOCATION;
				RandomizeRockTypes(i);
			}

			RandomRoomRockLayout();

			gameState = GAME;
		}

		private void UpdateGame(GameTime gameTime)
		{
			playerFireRateTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			playerImmunityTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			batEnemiesSpawnTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			coffeeEffectTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			mainCharJAnim[charDirection].Update(gameTime); 
			UICoffeeAnim.Update(gameTime);
			coffeeAnim.Update(gameTime);

			for (int i = 0; i < batEnemiesToSpawn; i++)
			{
				batEnemyAnim[i].Update(gameTime);
			}

			//Move and face a direction depending on input
			if ((kb.IsKeyDown(Keys.W)|| kb.IsKeyDown(Keys.S)) && (kb.IsKeyDown(Keys.A) || kb.IsKeyDown(Keys.D)))
			{
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= maxDiagonalSpeed;
				}

				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += maxDiagonalSpeed;
				}

				mainCharCenterLoc.X = (mainCharLoc.X + ((mainCharJImg[charDirection].Width / 4) * 0.5f * 0.5f));
				mainCharCenterLoc.Y = (mainCharLoc.Y + (mainCharJImg[charDirection].Height * 0.5f * 0.5f));
			}
			else
			{
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= currentMaxSpeed;
				}

				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += currentMaxSpeed;
				}

				mainCharCenterLoc.X = mainCharJAnim[charDirection].destRec.Center.X;
				mainCharCenterLoc.Y = mainCharJAnim[charDirection].destRec.Center.Y;
			}

			for (int i = 0; i < 4; i++)
			{
				mainCharJAnim[i].destRec.X = (int)mainCharLoc.X;
				mainCharJAnim[i].destRec.Y = (int)mainCharLoc.Y;
			}

			if (mouse.LeftButton == ButtonState.Pressed && playerFireRateTimer.IsFinished())
			{
				playerBulletAngle = (float)Math.Atan((mouse.Y - mainCharCenterLoc.Y) / ((mouse.X - mainCharCenterLoc.X)));
				
				if (mouse.X < mainCharCenterLoc.X)
				{
					playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Cos(playerBulletAngle);//
					playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Sin(playerBulletAngle);
				}
				else
				{
					playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Cos(playerBulletAngle);
					playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Sin(playerBulletAngle);
				}
				
				playerBulletsLoc[playerBulletsCount] = mainCharCenterLoc;
				playerBulletsCount++;

				playerFireRateTimer.ResetTimer(true);
			}

			for (int i = 0; i < numRocks; i++)
			{
				if (mainCharJAnim[charDirection].destRec.Intersects(rocksRec[i]))
				{
					charDistFromRockX = mainCharCenterLoc.X - rocksRec[i].Center.X;
					charDistFromRockY = mainCharCenterLoc.Y - rocksRec[i].Center.Y;

					if (charDistFromRockX < rocksRec[i].Width / 2 && charDistFromRockX > 0 && Math.Abs(charDistFromRockX) > Math.Abs(charDistFromRockY))
					{
						mainCharLoc.X+=currentMaxSpeed;
					}
					else if (charDistFromRockX > -rocksRec[i].Width / 2 && charDistFromRockX < 0 && Math.Abs(charDistFromRockX) > Math.Abs(charDistFromRockY))
					{
						mainCharLoc.X-=currentMaxSpeed; 
					}

					if (charDistFromRockY < rocksRec[i].Height / 2 && charDistFromRockY > 0 && Math.Abs(charDistFromRockX) < Math.Abs(charDistFromRockY))
					{
						mainCharLoc.Y+=currentMaxSpeed;
					}
					else if (charDistFromRockY > -rocksRec[i].Height / 1.5 && charDistFromRockY < 0 && Math.Abs(charDistFromRockX) < Math.Abs(charDistFromRockY))
					{
						mainCharLoc.Y-=currentMaxSpeed;
					}
				}
			}

			if (mainCharJAnim[charDirection].destRec.Intersects(coffeeAnim.destRec))
			{
				//make the player's held item a coffee unless they already have an item, and activate the effect on the spot
				if (currentPlayerItem == NO_ITEM)
				{
					currentPlayerItem = COFFEE;
				}
				else
				{
					CoffeeActivation();
				}

				coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
				coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
				isCoffeeInRoom = false;
			}

			if (coffeeEffectTimer.IsFinished())
			{
				coffeeEffectTimer.ResetTimer(false);
				currentMaxSpeed -= 1;
				maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
			}

			if (kb.IsKeyDown(Keys.Space))
			{
				switch (currentPlayerItem)
				{
					case 1:
						CoffeeActivation();
						UICoffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
						UICoffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
						break;
				}

				currentPlayerItem = 0;
			}

			switch (currentPlayerItem)
			{
				case 1:
					UICoffeeAnim.destRec.X = (int)UIItemLoc.X;
					UICoffeeAnim.destRec.Y = (int)UIItemLoc.Y;
					break;
			}
			
			for (int i = 0; i < playerBulletsCount; i++)
			{
				playerBulletsLoc[i].X += playerBulletSpeedX[i];
				playerBulletsLoc[i].Y += playerBulletSpeedY[i];
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;

				for (int j = 0; j < batEnemiesCount; j++)
				{
					batEnemiesLoc[j] = EnemyDeath(batEnemyAnim[j], batEnemiesLoc, i, j);
				}
				
				if ( playerBulletsRec[i].X != HIDE_OBJECTS_LOCATION && (playerBulletsRec[i].X > screenWidth - BORDER_OFFSET - UI_OFFSET || playerBulletsRec[i].X < BORDER_OFFSET + UI_OFFSET || playerBulletsRec[i].Y > screenHeight - BORDER_OFFSET || playerBulletsRec[i].Y < BORDER_OFFSET))
				{
					DeleteBullet(i);
				}
			}

			if (batEnemiesSpawned < batEnemiesToSpawn && batEnemiesSpawnTimer.IsFinished())
			{
				randomEnemySpawnDirection = rng.Next(0, 100);
				batEnemiesLoc[batEnemiesCount] = EnemySpawning();
				batEnemyAnim[batEnemiesCount].destRec.X = (int)batEnemiesLoc[batEnemiesCount].X;
				batEnemyAnim[batEnemiesCount].destRec.Y = (int)batEnemiesLoc[batEnemiesCount].Y;
				batEnemiesCount++;
				batEnemiesSpawned++;
				batEnemiesSpawnTimer.ResetTimer(true);
			}

			for (int i = 0; i < batEnemiesCount; i++)
			{
				batEnemiesCenterLoc[i].X = (batEnemiesLoc[i].X + (batEnemyImg.Width / 4 * 0.5f));
				batEnemiesCenterLoc[i].Y = (batEnemiesLoc[i].Y + (batEnemyImg.Height * 0.5f));

				if (batEnemyAnim[i].destRec.Intersects(mainCharJAnim[charDirection].destRec) && playerImmunityTimer.IsFinished())
				{
					playerJHealth--;
					playerImmunityTimer.ResetTimer(true);
				}

				BatMoving(i);
			}

			totalEnemyCount = batEnemiesToSpawn - batEnemiesSpawned;

			if (totalEnemyCount <= 0 && batEnemiesCount <= 0)
			{
				downArrowRec.X = (int)downArrowLoc.X;
				downArrowRec.Y = (int)downArrowLoc.Y;

				if (mainCharJAnim[charDirection].destRec.Intersects(enemySpawnFloorsRec[DOWN]))
				{
					currentRound++;

					if (batEnemiesToSpawn + 5 < 100)
					{
						batEnemiesToSpawn = 20 + (5 * (currentRound - 1));
					}

					coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
					coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
					isCoffeeInRoom = false;

					RandomRoomRockLayout();

					batEnemiesSpawned = 0;
					mainCharLoc = roomCharacterStartLoc;
				}
			}
			else
			{
				downArrowRec.X = (int)HIDE_OBJECTS_LOCATION;
				downArrowRec.Y = (int)HIDE_OBJECTS_LOCATION;
			}

			if (playerJHealth <= 0)
			{
				gameState = ENDGAME;
			}
		}

		private void UpdateEndGame()
		{
			if (retryButtonRec.Contains(mouse.Position) && mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton != ButtonState.Pressed)
			{
				gameState = PREGAME;
			}
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.Black);

			// TODO: Add your drawing code here
			spriteBatch.Begin();
			switch (gameState)
			{
				case MENU:
					DrawMenu();
					break;
				case PREGAME:
					DrawPregame();
					break;
				case GAME:
					DrawGame();
					break;
				case ENDGAME:
					DrawEndGame();
					break;
			}
			spriteBatch.End();

			base.Draw(gameTime);
		}

		private void DrawMenu()
		{
			
		}

		private void DrawPregame()
		{

		}

		private void DrawGame()
		{
			spriteBatch.Draw(wallBkImg, wallBkRec, Color.White);
			spriteBatch.Draw(floorBkImg, floorBkRec, Color.White);

			for (int i = 0; i < 4; i++)
			{
				spriteBatch.Draw(floorBkImg, enemySpawnFloorsRec[i], Color.Gray);
			}

			for (int i = 0; i < 20; i++)
			{
				spriteBatch.Draw(randomRocksImg[i], rocksRec[i], Color.White);
			}

			spriteBatch.Draw(downArrowImg, downArrowRec, Color.White);

			mainCharJAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);

			for (int i = 0; i <= playerBulletsCount; i++)
			{
				spriteBatch.Draw(metalBulletImg, playerBulletsRec[i], Color.White);
			}

			for (int i = 0; i < batEnemiesCount; i++)
			{
				batEnemyAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
			}

			coffeeAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);

			spriteBatch.Draw(heartImg, heartJLoc, Color.White);
			spriteBatch.DrawString(gameFont, Convert.ToString(playerJHealth), healthJLoc, Color.White);
			UICoffeeAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
		}

		private void DrawEndGame()
		{
			spriteBatch.Draw(retryButtonImg, retryButtonRec, Color.White);
		}

		private void BatMoving(int batNumber)
		{
			if (mainCharCenterLoc.X - batEnemiesCenterLoc[batNumber].X < 0)
			{
				batEnemiesLoc[batNumber].X -= BASE_BAT_SPEED;
			}
			else if (mainCharCenterLoc.X - batEnemiesCenterLoc[batNumber].X > 0)
			{
				batEnemiesLoc[batNumber].X += BASE_BAT_SPEED;
			}

			if (mainCharCenterLoc.Y - batEnemiesCenterLoc[batNumber].Y < 0)
			{
				batEnemiesLoc[batNumber].Y -= BASE_BAT_SPEED;
			}
			else if (mainCharCenterLoc.Y - batEnemiesCenterLoc[batNumber].Y > 0)
			{
				batEnemiesLoc[batNumber].Y += BASE_BAT_SPEED;
			}

			batEnemyAnim[batNumber].destRec.X = (int)batEnemiesLoc[batNumber].X;
			batEnemyAnim[batNumber].destRec.Y = (int)batEnemiesLoc[batNumber].Y;
		}

		private Vector2 EnemyDeath(Animation enemyAnim, Vector2[] enemyLoc, int bullet, int enemy)
		{
			if (enemyAnim.destRec.Intersects(playerBulletsRec[bullet]))
			{
				if (rng.Next(0, 99) <= 24 && isCoffeeInRoom == false)
				{
					coffeeAnim.destRec.X = (int)enemyLoc[enemy].X;
					coffeeAnim.destRec.Y = (int)enemyLoc[enemy].Y;
					isCoffeeInRoom = true;
				}

				for (int j = enemy; j < batEnemiesCount; j++)
				{
					enemyLoc[j].X = enemyLoc[j + 1].X;
					enemyLoc[j].Y = enemyLoc[j + 1].Y;
				}

				DeleteBullet(bullet);

				batEnemiesCount--;
			}

			return enemyLoc[enemy];
		}

		private void DeleteBullet (int bullet)
		{
			for (int i = bullet; i < playerBulletsCount; i++)
			{
				playerBulletSpeedX[i] = playerBulletSpeedX[i + 1];
				playerBulletSpeedY[i] = playerBulletSpeedY[i + 1];
				playerBulletsLoc[i].X = playerBulletsLoc[i + 1].X;
				playerBulletsLoc[i].Y = playerBulletsLoc[i + 1].Y;
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;
			}

			playerBulletsCount--;
		}

		private Vector2 EnemySpawning()
		{
			if (randomEnemySpawnDirection <= 24)
			{
				return enemySpawnsLoc[DOWN];
			}
			else if (randomEnemySpawnDirection <= 49)
			{
				return enemySpawnsLoc[LEFT];
			}
			else if (randomEnemySpawnDirection <= 74)
			{
				return enemySpawnsLoc[RIGHT];
			}
			else
			{
				return enemySpawnsLoc[UP];
			}
		}

		private void CoffeeActivation()
		{
			if (coffeeEffectTimer.IsInactive())
			{
				coffeeEffectTimer.Activate();
				currentMaxSpeed += 1;
			}
			else
			{
				coffeeEffectTimer.ResetTimer(true);
			}

			maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
		}

		private void RandomRoomRockLayout()
		{
			int randomRoom = rng.Next(0, 100);

			if (randomRoom <= 19)
			{
				for (int i = 0; i < roomType1X.Length; i++)
				{
					rocksRec[i].X = (int)roomType1X[i];
					rocksRec[i].Y = (int)roomType1Y[i];
					numRocks = (byte)roomType1X.Length;
				}
			}
			else if (randomRoom <= 39)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else if (randomRoom <= 59)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else if (randomRoom <= 79)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else
			{
				for (int i = 0; i < roomType1X.Length; i++)
				{
					rocksRec[i].X = (int)roomType1X[i];
					rocksRec[i].Y = (int)roomType1Y[i];
					numRocks = (byte)roomType1X.Length;
				}
			}
		}

		private void RandomizeRockTypes(int currentRock)
		{
			int randomRockType = rng.Next(0, 99);

			if (randomRockType <= 32)
			{
				randomRocksImg[currentRock] = rock1Img;
			}
			else if (randomRockType <= 65)
			{
				randomRocksImg[currentRock] = rock2Img;
			}
			else
			{
				randomRocksImg[currentRock] = rock3Img;
			}
		}

		/*private Animation RockCollision (Animation currentAnim)
		{
			

			return currentAnim;
		}*/
	}
}
