﻿//
using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Animation2D;
using Helper;

namespace PASS3Game
{
	/// <summary>
	/// This is the main type for your game.
	/// </summary>
	public class Game1 : Game
	{
		const byte MENU = 0;
		const byte GAME = 1;
		const byte ENDGAME = 2;

		const byte DOWN = 0;
		const byte LEFT = 1;
		const byte RIGHT = 2;
		const byte UP = 3;

		const int SPEED = 5;

		private GraphicsDeviceManager graphics;
		private SpriteBatch spriteBatch;

		//height & width of the screen
		int screenWidth;
		int screenHeight;

		KeyboardState kb;

		Texture2D[] mainCharJImg = new Texture2D[4];

		Vector2 mainCharLoc;

		Rectangle mainCharRec;

		Animation[] mainCharJAnim = new Animation[4];

		byte gameState = 0;

		byte charDirection = 0;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
			// TODO: Add your initialization logic here

			//get the width and height of the window
			screenWidth = graphics.GraphicsDevice.Viewport.Width;
			screenHeight = graphics.GraphicsDevice.Viewport.Height;

			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			// Create a new SpriteBatch, which can be used to draw textures.
			spriteBatch = new SpriteBatch(GraphicsDevice);

			// TODO: use this.Content to load your game content here
			
			mainCharJImg[DOWN] = Content.Load<Texture2D>("Animations/CharacterJDOWN");
			mainCharJImg[LEFT] = Content.Load<Texture2D>("Animations/CharacterJLEFT");
			mainCharJImg[RIGHT] = Content.Load<Texture2D>("Animations/CharacterJRIGHT");
			mainCharJImg[UP] = Content.Load<Texture2D>("Animations/CharacterJUP");


			mainCharLoc = new Vector2(0, 0);

			mainCharRec = new Rectangle((int)mainCharLoc.X, (int)mainCharLoc.Y, (int)(mainCharJImg[DOWN].Width * 0.2), (int)(mainCharJImg[DOWN].Height * 0.2));

			mainCharJAnim[DOWN] = new Animation(mainCharJImg[DOWN], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 1, false);
			mainCharJAnim[LEFT] = new Animation(mainCharJImg[LEFT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 1, false);
			mainCharJAnim[RIGHT] = new Animation(mainCharJImg[RIGHT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 1, false);
			mainCharJAnim[UP] = new Animation(mainCharJImg[UP], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 1, false);
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// game-specific content.
		/// </summary>
		protected override void UnloadContent()
		{
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			kb = Keyboard.GetState();

			// TODO: Add your update logic here
			switch (gameState)
			{
				case MENU:
					UpdateMenu();
					break;
				case GAME:
					UpdateGame(gameTime);
					break;
				case ENDGAME:
					UpdateEndGame();
					break;
			}

			base.Update(gameTime);
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.CornflowerBlue);

			// TODO: Add your drawing code here
			spriteBatch.Begin();
			switch (gameState)
			{
				case MENU:
					DrawMenu();
					break;
				case GAME:
					DrawGame();
					break;
				case ENDGAME:
					DrawEndGame();
					break;
			}
			spriteBatch.End();

			base.Draw(gameTime);
		}

		private void UpdateMenu()
		{
			gameState = GAME;
		}

		private void UpdateGame(GameTime gameTime)
		{
			mainCharJAnim[charDirection].Update(gameTime);

			if (kb.IsKeyDown(Keys.S))
			{
				charDirection = DOWN;
				mainCharLoc.Y += SPEED;
			}

			if (kb.IsKeyDown(Keys.A))
			{
				charDirection = LEFT;
				mainCharLoc.X -= SPEED;
			}

			if (kb.IsKeyDown(Keys.D))
			{
				charDirection = RIGHT;
				mainCharLoc.X += SPEED;
			}

			if (kb.IsKeyDown(Keys.W))
			{
				charDirection = UP;
				mainCharLoc.Y -= SPEED;
			}

			for (int i = 0; i < 4; i++)
			{
				mainCharJAnim[i].destRec.X = (int)mainCharLoc.X;
				mainCharJAnim[i].destRec.Y = (int)mainCharLoc.Y;
			}

			mainCharJAnim[charDirection].isAnimating = true;
		}

		private void UpdateEndGame()
		{

		}

		private void DrawMenu()
		{
			
		}

		private void DrawGame()
		{
			mainCharJAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
		}

		private void DrawEndGame()
		{

		}
	}
}
