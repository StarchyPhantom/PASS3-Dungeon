﻿//Author: Benjamin Huynh
//File Name: Game1.cs
//Project Name: PASS2
//Creation Date: May. 24, 2022
//Modified Date: June. 09, 2022
//Description: 
using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Animation2D;
using Helper;

namespace PASS3Game
{
	/// <summary>
	/// This is the main type for your game.
	/// </summary>
	public class Game1 : Game
	{
		const byte MENU = 0;
		const byte INSTRUCTIONS = 1;
		const byte PREGAME = 2;
		const byte GAME = 3;
		const byte UPGRADE = 4;
		const byte ENDGAME = 5;

		const byte DOWN = 0;
		const byte LEFT = 1;
		const byte RIGHT = 2;
		const byte UP = 3;

		const byte OFF = 0;
		const byte ON = 1;

		const byte NO_ITEM = 0;
		const byte COFFEE = 1;

		const byte BOOTS = 0;
		const byte CLOCK = 1;
		const byte THREE_BULLETS = 2;
		const byte SHIELD = 3;

		const float BASE_SPEED = 2;
		const float BASE_BULLET_SPEED = 3;
		const float BASE_BAT_SPEED = 1.5f;

		const float HIDE_OBJECTS_LOCATION = -400;

		const int BASE_FIRE_RATE_J = 575;
		const int BASE_FIRE_RATE_E = 1250;
		const int MAX_BULLETS = 100;

		const int MULTISHOT_OFFSET = 15;

		const int BORDER_OFFSET = 50;

		const int UI_OFFSET = 150;
		const int UI_ICON_OFFSET = 10;

		const int UPGRADE_SIZE = 200;

		const int MAX_BATS = 100;
		const int MAX_ROBOTS = 50;

		private GraphicsDeviceManager graphics;
		private SpriteBatch spriteBatch;

		//height & width of the screen
		int screenWidth;
		int screenHeight;

		static Random rng = new Random();

		//the keys pressed on the keyboard
		KeyboardState kb;

		//the state of the mouse
		MouseState mouse;
		MouseState prevMouse;

		SpriteFont gameFont;

		Texture2D[] mainCharJImg = new Texture2D[4];
		Texture2D[] mainCharEImg = new Texture2D[4];
		Texture2D[] robotEnemyImg = new Texture2D[4];
		Texture2D[] randomRocksImg = new Texture2D[20];

		Texture2D heartImg;
		Texture2D brokenHeartImg;

		Texture2D[] upgradesImg = new Texture2D[4];

		Texture2D floorBkImg;
		Texture2D wallBkImg;
		Texture2D blackPathImg;
		Texture2D downArrowImg;
		Texture2D rock1Img;
		Texture2D rock2Img;
		Texture2D rock3Img;

		Texture2D metalBulletImg;
		Texture2D woodBulletImg;
		Texture2D enemyBulletImg;
		Texture2D smokeTagImg;
		Texture2D batEnemyImg;
		Texture2D coffeeImg;

		Texture2D[] startImg = new Texture2D[2];
		Texture2D[] intsImg = new Texture2D[2];
		Texture2D[] menuImg = new Texture2D[2];
		Texture2D[] retryImg = new Texture2D[2];

		Vector2[] enemySpawnFloorsLoc = new Vector2[4];
		Vector2[] enemySpawnsLoc = new Vector2[4];
		Vector2[] playerBulletsLoc = new Vector2[MAX_BULLETS];
		Vector2[] batEnemiesLoc = new Vector2[MAX_BATS];
		Vector2[] robotEnemiesLoc = new Vector2[MAX_ROBOTS];

		Vector2 hideObjectsLoc;
		Vector2 roomCharacterStartLoc;

		Vector2 floorBkLoc;
		Vector2 wallBkLoc;

		Vector2 downArrowLoc;

		Vector2 heartJLoc;
		Vector2 heartELoc;
		Vector2 healthJLoc;
		Vector2 healthELoc;

		Vector2 upgrade1Loc;
		Vector2 upgrade2Loc;

		Vector2 mainCharLoc;
		Vector2 mainCharCenterLoc;
		Vector2 UIItemLoc;
		Vector2 UIMultiShotLoc;
		Vector2 coffeeLoc;

		Vector2 startBtnLoc;
		Vector2 intsBtnLoc;
		Vector2 menuBtnLoc;
		Vector2 retryBtnLoc;

		Rectangle[] enemySpawnFloorsRec = new Rectangle[4];
		Rectangle[] rocksRec = new Rectangle[20];
		Rectangle[] playerBulletsRec = new Rectangle[MAX_BULLETS];
		Rectangle[] enemyBulletsRec = new Rectangle[MAX_BULLETS];

		Rectangle floorBkRec;
		Rectangle wallBkRec;

		Rectangle downArrowRec;

		Rectangle mainCharRec;

		Rectangle heartJRec;
		Rectangle heartERec;
		Rectangle UIMultishotRec;

		Rectangle[] upgradesRec = new Rectangle[4];

		Rectangle startBtnRec;
		Rectangle intsBtnRec;
		Rectangle menuBtnRec;
		Rectangle retryBtnRec;

		Animation[] mainCharJAnim = new Animation[4];
		Animation[] mainCharEAnim = new Animation[4];
		Animation[] batEnemyAnim = new Animation[MAX_BATS];
		Animation[] robotEnemyDownAnim = new Animation[MAX_ROBOTS];
		Animation[] robotEnemyLeftAnim = new Animation[MAX_ROBOTS];
		Animation[] robotEnemyRightAnim = new Animation[MAX_ROBOTS];
		Animation[] robotEnemyUpAnim = new Animation[MAX_ROBOTS];
		Animation smokeTagAnim;
		Animation UICoffeeAnim;
		Animation coffeeAnim;

		Timer playerFireRateTimer;
		Timer playerImmunityTimer;
		Timer tagDelayTimer;
		Timer charEPierceTimer;

		Timer batEnemiesSpawnTimer;
		Timer robotEnemiesSpawnTimer;
		Timer[] robotRandomShootTimer = new Timer[50];

		Timer coffeeEffectTimer;

		byte gameState = 0;

		byte numRocks;
		byte charDirection = 0;
		byte currentPlayerItem = NO_ITEM;

		int currentRound = 1;

		int randomEnemySpawnDirection = 0;

		int randomUpgradeLeft;
		int randomUpgradeRight;

		int playerJHealth = 5;
		int playerEHealth = 4;
		int playerBulletsCount = 0;
		int storedMultiShot = 0;
		int currentMultiShotAngle = 0;
		int timesImmuneUpgraded = 0;

		int totalEnemyCount= 0;
		int batEnemiesCount = 0;
		int batEnemiesToSpawn = 20;
		int batEnemiesSpawned = 0;
		int robotEnemiesCount = 0;
		int robotEnemiesToSpawn = 0;
		int robotEnemiesSpawned = 0;
		int numRobotBullets = 0;
		int[] robotDirections = new int[MAX_ROBOTS];
		int[] robotHealths = new int[MAX_ROBOTS];
		int[] robotBulletSpeedX = new int[MAX_BULLETS];
		int[] robotBulletSpeedY = new int[MAX_BULLETS];

		float[] roomLayoutX = new float[5];
		float[] roomLayoutY = new float[5];
		float[] roomType1X;
		float[] roomType1Y;
		float[] roomType2X;
		float[] roomType2Y;

		float currentMaxSpeed = BASE_SPEED;
		float maxDiagonalSpeed = (float)Math.Sqrt(BASE_SPEED);

		float fireRateMultiplier = 1;
		float[] playerBulletSpeedX = new float[MAX_BULLETS];
		float[] playerBulletSpeedY = new float[MAX_BULLETS];
		float playerBulletAngle;

		float charDistFromRockX;
		float charDistFromRockY;
		float charDistFromRobotX;
		float charDistFromRobotY;

		bool[] isUpgradeActive = new bool []{ false, false, false, false };
		bool upgradeOptionChosen = false;

		bool[] isBulletOfJ = new bool[100];
		bool isJActive = true;
		bool isCoffeeInRoom = false;

		bool startBtn = false;
		bool intsBtn = false;
		bool menuBtn = false;
		bool retryBtn = false;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
			// TODO: Add your initialization logic here

			graphics.PreferredBackBufferWidth = 768 + UI_OFFSET * 2;
			graphics.PreferredBackBufferHeight = 768;

			graphics.ApplyChanges();

			IsMouseVisible = true;

			//get the width and height of the window
			screenWidth = graphics.GraphicsDevice.Viewport.Width;
			screenHeight = graphics.GraphicsDevice.Viewport.Height;

			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			// Create a new SpriteBatch, which can be used to draw textures.
			spriteBatch = new SpriteBatch(GraphicsDevice);

			// TODO: use this.Content to load your game content here

			gameFont = Content.Load<SpriteFont>("Fonts/GameFont");

			blackPathImg = Content.Load<Texture2D>("Backgrounds/BlackPanel");
			floorBkImg = Content.Load<Texture2D>("Backgrounds/GreyWall");
			wallBkImg = Content.Load<Texture2D>("Backgrounds/BlueWall");
			downArrowImg = Content.Load<Texture2D>("Sprites/DownArrow");
			rock1Img = Content.Load<Texture2D>("Sprites/Stone1");
			rock2Img = Content.Load<Texture2D>("Sprites/Stone2");
			rock3Img = Content.Load<Texture2D>("Sprites/Stone3");

			heartImg = Content.Load<Texture2D>("Sprites/Heart");
			brokenHeartImg = Content.Load<Texture2D>("Sprites/BrokenHeart");

			upgradesImg[BOOTS] = Content.Load<Texture2D>("Sprites/Boot");
			upgradesImg[CLOCK] = Content.Load<Texture2D>("Sprites/Clock");
			upgradesImg[THREE_BULLETS] = Content.Load<Texture2D>("Sprites/3Bullets");
			upgradesImg[SHIELD] = Content.Load<Texture2D>("Sprites/Shield");

			mainCharJImg[DOWN] = Content.Load<Texture2D>("Animations/CharacterJDOWN");
			mainCharJImg[LEFT] = Content.Load<Texture2D>("Animations/CharacterJLEFT");
			mainCharJImg[RIGHT] = Content.Load<Texture2D>("Animations/CharacterJRIGHT");
			mainCharJImg[UP] = Content.Load<Texture2D>("Animations/CharacterJUP");

			mainCharEImg[DOWN] = Content.Load<Texture2D>("Animations/CharacterEDOWN");
			mainCharEImg[LEFT] = Content.Load<Texture2D>("Animations/CharacterELEFT");
			mainCharEImg[RIGHT] = Content.Load<Texture2D>("Animations/CharacterERIGHT");
			mainCharEImg[UP] = Content.Load<Texture2D>("Animations/CharacterEUP");

			smokeTagImg = Content.Load<Texture2D>("Animations/Smoke");

			metalBulletImg = Content.Load<Texture2D>("Sprites/MetalBullet");
			woodBulletImg = Content.Load<Texture2D>("Sprites/WoodBullet");
			enemyBulletImg = Content.Load<Texture2D>("Sprites/RedBullet");
			batEnemyImg = Content.Load<Texture2D>("Animations/BatEnemy");
			robotEnemyImg[DOWN] = Content.Load<Texture2D>("Animations/RobotEnemyDOWN");
			robotEnemyImg[LEFT] = Content.Load<Texture2D>("Animations/RobotEnemyLEFT");
			robotEnemyImg[RIGHT] = Content.Load<Texture2D>("Animations/RobotEnemyRIGHT");
			robotEnemyImg[UP] = Content.Load<Texture2D>("Animations/RobotEnemyUP");
			coffeeImg = Content.Load<Texture2D>("Animations/Coffee");

			startImg[OFF] = Content.Load<Texture2D>("Sprites/StartOFF");
			startImg[ON] = Content.Load<Texture2D>("Sprites/StartON");
			intsImg[OFF] = Content.Load<Texture2D>("Sprites/IntsOFF");
			intsImg[ON] = Content.Load<Texture2D>("Sprites/IntsON");
			menuImg[OFF] = Content.Load<Texture2D>("Sprites/MenuOFF");
			menuImg[ON] = Content.Load<Texture2D>("Sprites/MenuON");
			retryImg[OFF] = Content.Load<Texture2D>("Sprites/RetryOFF");
			retryImg[ON] = Content.Load<Texture2D>("Sprites/RetryON");

			hideObjectsLoc = new Vector2(HIDE_OBJECTS_LOCATION, HIDE_OBJECTS_LOCATION);
			roomCharacterStartLoc = new Vector2(screenWidth / 2 - mainCharJImg[DOWN].Width / 2 / 2 / 4, screenHeight / 2 - mainCharJImg[DOWN].Height / 2 / 2);

			floorBkLoc = new Vector2(BORDER_OFFSET + UI_OFFSET, BORDER_OFFSET);
			wallBkLoc = new Vector2(UI_OFFSET, 0);

			downArrowLoc = new Vector2(screenWidth / 2 - downArrowImg.Width / 2, screenHeight / 1.5f);

			heartJLoc = new Vector2(UI_OFFSET / 2 - heartImg.Width/ 2, screenHeight / 4);
			heartELoc = new Vector2(screenWidth - (UI_OFFSET / 2 + heartImg.Width / 2), screenHeight / 4);
			healthJLoc = new Vector2(heartJLoc.X + heartImg.Width + UI_ICON_OFFSET, heartJLoc.Y);
			healthELoc = new Vector2(heartELoc.X - heartImg.Width + UI_ICON_OFFSET, heartELoc.Y);

			upgrade1Loc = new Vector2(screenWidth / 3 - UPGRADE_SIZE / 2, screenHeight / 2 - UPGRADE_SIZE / 2);
			upgrade2Loc = new Vector2(screenWidth / 3 * 2 - UPGRADE_SIZE / 2, screenHeight / 2 - UPGRADE_SIZE / 2);

			mainCharLoc = roomCharacterStartLoc;
			mainCharCenterLoc = new Vector2(BORDER_OFFSET, BORDER_OFFSET);

			UIItemLoc = new Vector2(UI_OFFSET / 2 - coffeeImg.Width / 2, screenHeight / 2);
			coffeeLoc = hideObjectsLoc;

			startBtnLoc = new Vector2(screenWidth / 2 - startImg[OFF].Width * 4 / 2, screenHeight / 1.5f - startImg[OFF].Height * 4 / 2);
			intsBtnLoc = new Vector2(screenWidth / 2 - intsImg[OFF].Width * 4 / 2, screenHeight / 2 - intsImg[OFF].Height * 4 / 2);
			menuBtnLoc = new Vector2(screenWidth / 2 - menuImg[OFF].Width * 4 / 2, screenHeight / 1.5f - menuImg[OFF].Height * 4 / 2);
			retryBtnLoc = new Vector2(screenWidth / 2 - retryImg[OFF].Width * 4 / 2, screenHeight / 2 - retryImg[OFF].Height * 4 / 2);

			enemySpawnFloorsLoc[DOWN] = new Vector2(screenWidth / 2 - BORDER_OFFSET / 2 * 3, screenHeight - BORDER_OFFSET);
			enemySpawnFloorsLoc[LEFT] = new Vector2(UI_OFFSET, screenHeight / 2 - BORDER_OFFSET / 2 * 3);
			enemySpawnFloorsLoc[RIGHT] = new Vector2(screenWidth - UI_OFFSET - BORDER_OFFSET, screenHeight / 2 - BORDER_OFFSET / 2 * 3);
			enemySpawnFloorsLoc[UP] = new Vector2(screenWidth / 2 - BORDER_OFFSET / 2 * 3, 0);

			enemySpawnsLoc[DOWN] = new Vector2(screenWidth / 2, screenHeight);
			enemySpawnsLoc[LEFT] = new Vector2(UI_OFFSET, screenHeight / 2);
			enemySpawnsLoc[RIGHT] = new Vector2(screenWidth - UI_OFFSET, screenHeight / 2);
			enemySpawnsLoc[UP] = new Vector2(screenWidth / 2, 0);

			for (int i = 0; i < MAX_BULLETS ; i++)
			{
				playerBulletsLoc[i] = hideObjectsLoc;
				playerBulletsRec[i] = new Rectangle((int)playerBulletsLoc[i].X, (int)playerBulletsLoc[i].Y, (int)(metalBulletImg.Width * 0.5), (int)(metalBulletImg.Height * 0.5));
				playerBulletSpeedX[i] = 0;
				playerBulletSpeedY[i] = 0;
				enemyBulletsRec[i] = new Rectangle((int)hideObjectsLoc.X, (int)hideObjectsLoc.Y, (int)(enemyBulletImg.Width * 0.5), (int)(enemyBulletImg.Height * 0.5));
				robotBulletSpeedX[i] = 0;
				robotBulletSpeedY[i] = 0;
			}

			for (int i = 0; i < MAX_BATS; i++)
			{
				batEnemiesLoc[i] = hideObjectsLoc;
				batEnemyAnim[i] = new Animation(batEnemyImg, 4, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, batEnemiesLoc[i], 1, true);
			}

			for (int i = 0; i < MAX_ROBOTS; i++)
			{
				robotEnemiesLoc[i] = hideObjectsLoc;
				robotEnemyDownAnim[i] = new Animation(robotEnemyImg[DOWN], 6, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, robotEnemiesLoc[i], 1, true);
				robotEnemyLeftAnim[i] = new Animation(robotEnemyImg[LEFT], 6, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, robotEnemiesLoc[i], 1, true);
				robotEnemyRightAnim[i] = new Animation(robotEnemyImg[RIGHT], 6, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, robotEnemiesLoc[i], 1, true);
				robotEnemyUpAnim[i] = new Animation(robotEnemyImg[UP], 6, 1, 4, 0, 0, Animation.ANIMATE_FOREVER, 10, robotEnemiesLoc[i], 1, true);
				robotRandomShootTimer[i] = new Timer(rng.Next(5000, 7501), false);
			}

			for (int i = 0; i < 20; i++)
			{
				rocksRec[i] = new Rectangle((int)HIDE_OBJECTS_LOCATION, (int)HIDE_OBJECTS_LOCATION, rock1Img.Width * 2, rock1Img.Height * 2);
			}

			floorBkRec = new Rectangle((int)floorBkLoc.X, (int)floorBkLoc.Y, screenWidth - (BORDER_OFFSET * 2) - UI_OFFSET * 2, screenHeight - (BORDER_OFFSET * 2));
			wallBkRec = new Rectangle((int)wallBkLoc.X, (int)wallBkLoc.Y, screenWidth - UI_OFFSET * 2, screenHeight);

			downArrowRec = new Rectangle((int)HIDE_OBJECTS_LOCATION, (int)HIDE_OBJECTS_LOCATION, downArrowImg.Width, downArrowImg.Height);

			heartJRec = new Rectangle((int)heartJLoc.X, (int)heartJLoc.Y, heartImg.Width, heartImg.Height);
			heartERec = new Rectangle((int)heartELoc.X, (int)heartELoc.Y, heartImg.Width, heartImg.Height);

			for (int i = 0; i < 4; i++)
			{
				upgradesRec[i] = new Rectangle((int)hideObjectsLoc.X, (int)hideObjectsLoc.Y, UPGRADE_SIZE, UPGRADE_SIZE);
			}

			mainCharRec = new Rectangle((int)mainCharLoc.X, (int)mainCharLoc.Y, (int)(mainCharJImg[DOWN].Width * 0.2), (int)(mainCharJImg[DOWN].Height * 0.2));

			startBtnRec = new Rectangle((int)startBtnLoc.X, (int)startBtnLoc.Y, startImg[OFF].Width * 4, startImg[OFF].Height * 4);
			intsBtnRec = new Rectangle((int)intsBtnLoc.X, (int)intsBtnLoc.Y, intsImg[OFF].Width * 4, intsImg[OFF].Height * 4);
			menuBtnRec = new Rectangle((int)menuBtnLoc.X, (int)menuBtnLoc.Y, menuImg[OFF].Width * 4, menuImg[OFF].Height * 4);
			retryBtnRec = new Rectangle((int)retryBtnLoc.X, (int)retryBtnLoc.Y, retryImg[OFF].Width * 4, retryImg[OFF].Height * 4);

			enemySpawnFloorsRec[DOWN] = new Rectangle((int)enemySpawnFloorsLoc[DOWN].X, (int)enemySpawnFloorsLoc[DOWN].Y, BORDER_OFFSET * 3, BORDER_OFFSET);
			enemySpawnFloorsRec[LEFT] = new Rectangle((int)enemySpawnFloorsLoc[LEFT].X, (int)enemySpawnFloorsLoc[LEFT].Y, BORDER_OFFSET, BORDER_OFFSET * 3);
			enemySpawnFloorsRec[RIGHT] = new Rectangle((int)enemySpawnFloorsLoc[RIGHT].X, (int)enemySpawnFloorsLoc[RIGHT].Y, BORDER_OFFSET, BORDER_OFFSET * 3);
			enemySpawnFloorsRec[UP] = new Rectangle((int)enemySpawnFloorsLoc[UP].X, (int)enemySpawnFloorsLoc[UP].Y, BORDER_OFFSET * 3, BORDER_OFFSET);

			mainCharJAnim[DOWN] = new Animation(mainCharJImg[DOWN], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[LEFT] = new Animation(mainCharJImg[LEFT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[RIGHT] = new Animation(mainCharJImg[RIGHT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);
			mainCharJAnim[UP] = new Animation(mainCharJImg[UP], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, mainCharLoc, 0.5f, true);

			mainCharEAnim[DOWN] = new Animation(mainCharEImg[DOWN], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 0.5f, true);
			mainCharEAnim[LEFT] = new Animation(mainCharEImg[LEFT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 0.5f, true);
			mainCharEAnim[RIGHT] = new Animation(mainCharEImg[RIGHT], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 0.5f, true);
			mainCharEAnim[UP] = new Animation(mainCharEImg[UP], 4, 1, 4, 0, 1, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 0.5f, true);

			smokeTagAnim = new Animation(smokeTagImg, 3, 2, 6, 1, 0, Animation.ANIMATE_FOREVER, 15, hideObjectsLoc, 1, false);
			UICoffeeAnim = new Animation(coffeeImg, 2, 1, 2, 0, 0, Animation.ANIMATE_FOREVER, 10, hideObjectsLoc, 1, true);
			coffeeAnim = new Animation(coffeeImg, 2, 1, 2, 0, 0, Animation.ANIMATE_FOREVER, 10, coffeeLoc, 1, true);

			tagDelayTimer = new Timer(5000, true);
			charEPierceTimer = new Timer(50, true);

			batEnemiesSpawnTimer = new Timer(rng.Next(500, 1501), true);
			robotEnemiesSpawnTimer = new Timer(rng.Next(1000, 2001), true);

			coffeeEffectTimer = new Timer(10000, false);

			roomType1X = new float[] { UI_OFFSET + BORDER_OFFSET,
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 4),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 5),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 6)};
			roomType1Y = new float[] { BORDER_OFFSET,
									   BORDER_OFFSET + (rock1Img.Height * 2),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 2),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 4),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 5),
									   BORDER_OFFSET + (rock1Img.Height * 2 * 6)};
			roomType2X = new float[] { UI_OFFSET + BORDER_OFFSET,
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 2),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 3),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 4),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 5),
									   UI_OFFSET + BORDER_OFFSET + (rock1Img.Width * 2 * 6)};
			roomType2Y = new float[] { screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2),
									   screenHeight / 2 + (rock1Img.Height * 2),
									   screenHeight / 2 - (rock1Img.Height * 2 * 2)};
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// game-specific content.
		/// </summary>
		protected override void UnloadContent()
		{
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			kb = Keyboard.GetState();
			prevMouse = mouse;
			mouse = Mouse.GetState();

			// TODO: Add your update logic here
			switch (gameState)
			{
				case MENU:
					UpdateMenu();
					break;
				case INSTRUCTIONS:
					UpdateInstructions();
					break;
				case PREGAME:
					UpdatePregame();
					break;
				case GAME:
					UpdateGame(gameTime);
					break;
				case UPGRADE:
					UpdateUpgrade();
					break;
				case ENDGAME:
					UpdateEndGame();
					break;
			}

			base.Update(gameTime);
		}

		private void UpdateMenu()
		{
			startBtn = startBtnRec.Contains(mouse.Position);
			intsBtn = intsBtnRec.Contains(mouse.Position);

			if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton != ButtonState.Pressed)
			{
				if (startBtnRec.Contains(mouse.Position))
				{
					gameState = PREGAME;
				}
				else if (intsBtnRec.Contains(mouse.Position))
				{
					gameState = INSTRUCTIONS;
				}
			}
		}

		private void UpdateInstructions()
		{

		}

		private void UpdatePregame()
		{
			currentRound = 1;
			playerJHealth = 5;
			playerEHealth = 4;
			currentMaxSpeed = BASE_SPEED;
			maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
			currentPlayerItem = NO_ITEM;
			playerBulletsCount = 0;
			storedMultiShot = 99;
			fireRateMultiplier = 1;
			mainCharLoc = roomCharacterStartLoc;
			coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
			coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			UICoffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
			UICoffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			coffeeEffectTimer.ResetTimer(false);
			isCoffeeInRoom = false;
			batEnemiesSpawned = 0;
			batEnemiesCount = 0;
			batEnemiesToSpawn = 20;
			robotEnemiesSpawned = 0;
			robotEnemiesCount = 0;
			robotEnemiesToSpawn = 0;

			for (int i = 0; i < 4; i++)
			{
				mainCharEAnim[i].destRec.X = (int)HIDE_OBJECTS_LOCATION;
				mainCharEAnim[i].destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			}

			playerImmunityTimer = new Timer(3000, true);
			playerFireRateTimer = new Timer(BASE_FIRE_RATE_J * fireRateMultiplier, true);
			isJActive = true;

			for (int i = 0; i < MAX_BATS; i++)
			{
				batEnemiesLoc[i] = hideObjectsLoc;
				batEnemyAnim[i].destRec.X = (int)batEnemiesLoc[i].X;
				batEnemyAnim[i].destRec.Y = (int)batEnemiesLoc[i].Y;
			}

			for (int i = 0; i < MAX_ROBOTS; i++)
			{
				robotEnemiesLoc[i] = hideObjectsLoc;
				robotEnemyDownAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyDownAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyLeftAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyLeftAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyRightAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyRightAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyUpAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyUpAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotHealths[i] = 3;
				robotDirections[i] = DOWN;
			}

			for (int i = 0; i < MAX_BULLETS; i++)
			{
				playerBulletsLoc[i] = hideObjectsLoc;
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;
				playerBulletSpeedX[i] = 0;
				playerBulletSpeedY[i] = 0;
			}

			for (int i = 0; i < 20; i++)
			{
				RandomizeRockTypes(i);
			}

			RandomRoomRockLayout();

			gameState = GAME;
		}

		private void UpdateGame(GameTime gameTime)
		{
			playerFireRateTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			playerImmunityTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			batEnemiesSpawnTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			robotEnemiesSpawnTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			coffeeEffectTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			tagDelayTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			charEPierceTimer.Update(gameTime.ElapsedGameTime.TotalMilliseconds);
			mainCharJAnim[charDirection].Update(gameTime);
			mainCharEAnim[charDirection].Update(gameTime);
			smokeTagAnim.Update(gameTime);
			UICoffeeAnim.Update(gameTime);
			coffeeAnim.Update(gameTime);

			for (int i = 0; i < batEnemiesCount; i++)
			{
				batEnemyAnim[i].Update(gameTime);
			}

			for (int i = 0; i < robotEnemiesCount; i++)
			{
				robotRandomShootTimer[i].Update(gameTime.ElapsedGameTime.TotalMilliseconds);

				if (robotDirections[i] == DOWN)
				{
					robotEnemyDownAnim[i].Update(gameTime);
				}
				else if (robotDirections[i] == LEFT)
				{
					robotEnemyLeftAnim[i].Update(gameTime);
				}
				else if (robotDirections[i] == RIGHT)
				{
					robotEnemyRightAnim[i].Update(gameTime);
				}
				else if (robotDirections[i] == UP)
				{
					robotEnemyUpAnim[i].Update(gameTime);
				}
			}

			//Move and face a direction depending on input
			if ((kb.IsKeyDown(Keys.W)|| kb.IsKeyDown(Keys.S)) && (kb.IsKeyDown(Keys.A) || kb.IsKeyDown(Keys.D)))
			{
				//move and face upwards if w is pressed
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= maxDiagonalSpeed;
				}

				//move and face downwards if s is pressed
				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += maxDiagonalSpeed;
				}

				//move and face left if a is pressed
				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= maxDiagonalSpeed;
				}

				//move and face right if d is pressed
				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += maxDiagonalSpeed;
				}

				//get center vector of character
				if (isJActive == true)
				{
					mainCharCenterLoc.X = mainCharJAnim[charDirection].destRec.Center.X;
					mainCharCenterLoc.Y = mainCharJAnim[charDirection].destRec.Center.Y;
				}
				else
				{
					mainCharCenterLoc.X = mainCharEAnim[charDirection].destRec.Center.X;
					mainCharCenterLoc.Y = mainCharEAnim[charDirection].destRec.Center.Y;
				}
			}
			else
			{
				//move and face upwards if w is pressed
				if (kb.IsKeyDown(Keys.W))
				{
					charDirection = UP;
					mainCharLoc.Y -= currentMaxSpeed;
				}

				//move and face downwards if s is pressed
				if (kb.IsKeyDown(Keys.S))
				{
					charDirection = DOWN;
					mainCharLoc.Y += currentMaxSpeed;
				}

				//move and face left if a is pressed
				if (kb.IsKeyDown(Keys.A))
				{
					charDirection = LEFT;
					mainCharLoc.X -= currentMaxSpeed;
				}

				//move and face right if d is pressed
				if (kb.IsKeyDown(Keys.D))
				{
					charDirection = RIGHT;
					mainCharLoc.X += currentMaxSpeed;
				}

				//get center vector of character
				if (isJActive == true)
				{
					mainCharCenterLoc.X = mainCharJAnim[charDirection].destRec.Center.X;
					mainCharCenterLoc.Y = mainCharJAnim[charDirection].destRec.Center.Y;
				}
				else
				{
					mainCharCenterLoc.X = mainCharEAnim[charDirection].destRec.Center.X;
					mainCharCenterLoc.Y = mainCharEAnim[charDirection].destRec.Center.Y;
				}
			}

			for (int i = 0; i < 4; i++)
			{
				if (isJActive == true)
				{
					mainCharJAnim[i].destRec.X = (int)mainCharLoc.X;
					mainCharJAnim[i].destRec.Y = (int)mainCharLoc.Y;
				}
				else
				{
					mainCharEAnim[i].destRec.X = (int)mainCharLoc.X;
					mainCharEAnim[i].destRec.Y = (int)mainCharLoc.Y;
				}
			}

			if (mouse.LeftButton == ButtonState.Pressed && playerFireRateTimer.IsFinished())
			{
				PlayerShooting();
			}

			for (int i = 0; i < numRocks; i++)
			{
				if ((mainCharJAnim[charDirection].destRec.Intersects(rocksRec[i]) && isJActive == true) || (mainCharEAnim[charDirection].destRec.Intersects(rocksRec[i]) && isJActive == false))
				{
					charDistFromRockX = mainCharCenterLoc.X - rocksRec[i].Center.X;
					charDistFromRockY = mainCharCenterLoc.Y - rocksRec[i].Center.Y;

					if (charDistFromRockX < rocksRec[i].Width / 2 && charDistFromRockX > 0 && Math.Abs(charDistFromRockX) > Math.Abs(charDistFromRockY))
					{
						mainCharLoc.X+=currentMaxSpeed;
					}
					else if (charDistFromRockX > -rocksRec[i].Width / 2 && charDistFromRockX < 0 && Math.Abs(charDistFromRockX) > Math.Abs(charDistFromRockY))
					{
						mainCharLoc.X-=currentMaxSpeed; 
					}

					if (charDistFromRockY < rocksRec[i].Height / 2 && charDistFromRockY > 0 && Math.Abs(charDistFromRockX) < Math.Abs(charDistFromRockY))
					{
						mainCharLoc.Y+=currentMaxSpeed;
					}
					else if (charDistFromRockY > -rocksRec[i].Height / 2 && charDistFromRockY < 0 && Math.Abs(charDistFromRockX) < Math.Abs(charDistFromRockY))
					{
						mainCharLoc.Y-=currentMaxSpeed;
					}
				}
			}

			if ((kb.IsKeyDown(Keys.E) && tagDelayTimer.IsFinished() && playerEHealth > 0 && playerJHealth > 0) || (playerJHealth <= 0 && isJActive == true) || (playerEHealth <= 0 && isJActive == false))
			{
				smokeTagAnim.isAnimating = true;
				tagDelayTimer.ResetTimer(true);
				
				if (isJActive == true)
				{
					smokeTagAnim.destRec.X = mainCharJAnim[charDirection].destRec.X - (smokeTagImg.Width / 3 - mainCharJImg[charDirection].Width / 4) / 2;
					smokeTagAnim.destRec.Y = mainCharJAnim[charDirection].destRec.Y - (smokeTagImg.Height / 2 - mainCharJImg[charDirection].Height) / 2;

					for (int i = 0; i < 4; i++)
					{
						mainCharJAnim[i].destRec.X = (int)HIDE_OBJECTS_LOCATION;
						mainCharJAnim[i].destRec.Y = (int)HIDE_OBJECTS_LOCATION;
					}

					playerFireRateTimer = new Timer(BASE_FIRE_RATE_E * fireRateMultiplier, true);
					isJActive = false;
				}
				else
				{
					smokeTagAnim.destRec.X = mainCharEAnim[charDirection].destRec.X - (smokeTagImg.Width / 3 - mainCharEImg[charDirection].Width / 4) / 2;
					smokeTagAnim.destRec.Y = mainCharEAnim[charDirection].destRec.Y - (smokeTagImg.Height / 2 - mainCharEImg[charDirection].Height) / 2;

					for (int i = 0; i < 4; i++)
					{
						mainCharEAnim[i].destRec.X = (int)HIDE_OBJECTS_LOCATION;
						mainCharEAnim[i].destRec.Y = (int)HIDE_OBJECTS_LOCATION;
					}

					playerFireRateTimer = new Timer(BASE_FIRE_RATE_J * fireRateMultiplier, true);
					isJActive = true;
				}
			}
			else if (smokeTagAnim.curFrame == 5)
			{
				smokeTagAnim.isAnimating = false;
				smokeTagAnim.curFrame = 0;
				smokeTagAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
				smokeTagAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
			}

			if (kb.IsKeyDown(Keys.Q) && playerFireRateTimer.IsFinished() && storedMultiShot > 0)
			{
				PlayerShooting();
				currentMultiShotAngle = MULTISHOT_OFFSET;
				PlayerShooting();
				currentMultiShotAngle = -MULTISHOT_OFFSET;
				PlayerShooting();
				currentMultiShotAngle = 0;

				storedMultiShot--;
			}

			if (isCoffeeInRoom == true && (mainCharJAnim[charDirection].destRec.Intersects(coffeeAnim.destRec) || mainCharEAnim[charDirection].destRec.Intersects(coffeeAnim.destRec)))
			{
				//make the player's held item a coffee unless they already have an item, and activate the effect on the spot
				if (currentPlayerItem == NO_ITEM)
				{
					currentPlayerItem = COFFEE;
				}
				else
				{
					CoffeeActivation();
				}

				coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
				coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
				isCoffeeInRoom = false;
			}

			if (coffeeEffectTimer.IsFinished())
			{
				coffeeEffectTimer.ResetTimer(false);
				currentMaxSpeed -= 1;
				maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
			}

			if (kb.IsKeyDown(Keys.Space))
			{
				switch (currentPlayerItem)
				{
					case 1:
						CoffeeActivation();
						UICoffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
						UICoffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
						break;
				}

				currentPlayerItem = 0;
			}

			switch (currentPlayerItem)
			{
				case 1:
					UICoffeeAnim.destRec.X = (int)UIItemLoc.X;
					UICoffeeAnim.destRec.Y = (int)UIItemLoc.Y;
					break;
			}
			
			for (int i = 0; i < playerBulletsCount; i++)
			{
				playerBulletsLoc[i].X += playerBulletSpeedX[i];
				playerBulletsLoc[i].Y += playerBulletSpeedY[i];
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;

				for (int j = 0; j < batEnemiesCount; j++)
				{
					if (batEnemyAnim[j].destRec.Intersects(playerBulletsRec[i]) && charEPierceTimer.IsFinished())
					{
						batEnemiesLoc[j] = EnemyDeath(batEnemiesLoc, i, j, batEnemiesCount);
						batEnemiesCount--;
					}
				}

				for (int j = 0; j < robotEnemiesCount; j++)
				{
					if (robotEnemyDownAnim[j].destRec.Intersects(playerBulletsRec[i]) && charEPierceTimer.IsFinished())
					{
						robotHealths[j]--;

						if (robotHealths[j] <= 0)
						{
							robotEnemiesLoc[j] = EnemyDeath(robotEnemiesLoc, i, j, robotEnemiesCount);
							robotEnemiesCount--;
						}
						else
						{
							DeleteBullet(i);
						}
					}
				}

				if (playerBulletsRec[i].X != HIDE_OBJECTS_LOCATION && !playerBulletsRec[i].Intersects(floorBkRec))
				{
					DeleteBullet(i);
				}
			}

			if (batEnemiesSpawned < batEnemiesToSpawn && batEnemiesSpawnTimer.IsFinished())
			{
				batEnemiesLoc[batEnemiesCount] = EnemySpawning();
				batEnemyAnim[batEnemiesCount].destRec.X = (int)batEnemiesLoc[batEnemiesCount].X;
				batEnemyAnim[batEnemiesCount].destRec.Y = (int)batEnemiesLoc[batEnemiesCount].Y;
				batEnemiesCount++;
				batEnemiesSpawned++;
				batEnemiesSpawnTimer.ResetTimer(true);
			}

			for (int i = 0; i < batEnemiesCount; i++)
			{
				if (batEnemyAnim[i].destRec.Intersects(mainCharJAnim[charDirection].destRec) && playerImmunityTimer.IsFinished())
				{
					playerJHealth--;
					playerImmunityTimer.ResetTimer(true);
				}
				else if (batEnemyAnim[i].destRec.Intersects(mainCharEAnim[charDirection].destRec) && playerImmunityTimer.IsFinished())
				{
					playerEHealth--;
					playerImmunityTimer.ResetTimer(true);
				}

				BatMoving(i);
			}

			if (robotEnemiesSpawned < robotEnemiesToSpawn && robotEnemiesSpawnTimer.IsFinished())
			{
				robotEnemiesLoc[robotEnemiesCount] = EnemySpawning();

				robotEnemyDownAnim[robotEnemiesCount].destRec.X = (int)robotEnemiesLoc[robotEnemiesCount].X;
				robotEnemyDownAnim[robotEnemiesCount].destRec.Y = (int)robotEnemiesLoc[robotEnemiesCount].Y;
				robotEnemyLeftAnim[robotEnemiesCount].destRec.X = (int)robotEnemiesLoc[robotEnemiesCount].X;
				robotEnemyLeftAnim[robotEnemiesCount].destRec.Y = (int)robotEnemiesLoc[robotEnemiesCount].Y;
				robotEnemyRightAnim[robotEnemiesCount].destRec.X = (int)robotEnemiesLoc[robotEnemiesCount].X;
				robotEnemyRightAnim[robotEnemiesCount].destRec.Y = (int)robotEnemiesLoc[robotEnemiesCount].Y;
				robotEnemyUpAnim[robotEnemiesCount].destRec.X = (int)robotEnemiesLoc[robotEnemiesCount].X;
				robotEnemyUpAnim[robotEnemiesCount].destRec.Y = (int)robotEnemiesLoc[robotEnemiesCount].Y;

				robotRandomShootTimer[robotEnemiesCount] = new Timer(rng.Next(5000, 7501), true);

				robotHealths[robotEnemiesCount] = 3;
				robotEnemiesCount++;
				robotEnemiesSpawned++;
				robotEnemiesSpawnTimer.ResetTimer(true);
			}

			for (int i = 0; i < robotEnemiesCount; i++)
			{
				charDistFromRobotX = mainCharCenterLoc.X - robotEnemyDownAnim[i].destRec.Center.X;
				charDistFromRobotY = mainCharCenterLoc.Y - robotEnemyDownAnim[i].destRec.Center.Y;

				if ((charDistFromRobotX < -300 || charDistFromRobotX > 300) || charDistFromRobotY < -50 || charDistFromRobotY > 50)
				{
					if (charDistFromRobotX < 0)
					{
						robotEnemiesLoc[i].X -= 1;
						robotDirections[i] = LEFT;
					}
					else if (charDistFromRobotX > 0)
					{
						robotEnemiesLoc[i].X += 1;
						robotDirections[i] = RIGHT;
					}
				}

				if ((charDistFromRobotY < -300 || charDistFromRobotY > 300) || charDistFromRobotX < -50 || charDistFromRobotX > 50)
				{
					if (charDistFromRobotY < 0)
					{
						robotEnemiesLoc[i].Y -= 1;
						robotDirections[i] = UP;
					}
					else if (charDistFromRobotY > 0)
					{
						robotEnemiesLoc[i].Y += 1;
						robotDirections[i] = DOWN;
					}
				}

				robotEnemyDownAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyDownAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyLeftAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyLeftAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyRightAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyRightAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;
				robotEnemyUpAnim[i].destRec.X = (int)robotEnemiesLoc[i].X;
				robotEnemyUpAnim[i].destRec.Y = (int)robotEnemiesLoc[i].Y;

				if (robotRandomShootTimer[i].IsFinished())
				{
					enemyBulletsRec[i + numRobotBullets].X = robotEnemyDownAnim[i].destRec.Center.X;
					enemyBulletsRec[i + numRobotBullets].Y = robotEnemyDownAnim[i].destRec.Center.Y;
					enemyBulletsRec[i + numRobotBullets + 1].X = robotEnemyDownAnim[i].destRec.Center.X;
					enemyBulletsRec[i + numRobotBullets + 1].Y = robotEnemyDownAnim[i].destRec.Center.Y;
					enemyBulletsRec[i + numRobotBullets + 2].X = robotEnemyDownAnim[i].destRec.Center.X;
					enemyBulletsRec[i + numRobotBullets + 2].Y = robotEnemyDownAnim[i].destRec.Center.Y;
					enemyBulletsRec[i + numRobotBullets + 3].X = robotEnemyDownAnim[i].destRec.Center.X;
					enemyBulletsRec[i + numRobotBullets + 3].Y = robotEnemyDownAnim[i].destRec.Center.Y;

					robotBulletSpeedX[i + numRobotBullets] = 0;
					robotBulletSpeedY[i + numRobotBullets] = 1;
					robotBulletSpeedX[i + numRobotBullets + 1] = 0;
					robotBulletSpeedY[i + numRobotBullets + 1] = -1;
					robotBulletSpeedX[i + numRobotBullets + 2] = -1;
					robotBulletSpeedY[i + numRobotBullets + 2] = 0;
					robotBulletSpeedX[i + numRobotBullets + 3] = 1;
					robotBulletSpeedY[i + numRobotBullets + 3] = 0;

					numRobotBullets += 4;

					robotRandomShootTimer[i] = new Timer(rng.Next(5000, 7501), true);
				}
			}

			for (int i = 0; i < numRobotBullets; i++)
			{
				enemyBulletsRec[i].X += robotBulletSpeedX[i];
				enemyBulletsRec[i].Y += robotBulletSpeedY[i];

				if (!enemyBulletsRec[i].Intersects(floorBkRec))
				{
					for (int j = i; j < numRobotBullets; j++)
					{
						robotBulletSpeedX[j] = robotBulletSpeedX[j + 1];
						robotBulletSpeedY[j] = robotBulletSpeedY[j + 1];
						enemyBulletsRec[j].X = enemyBulletsRec[j + 1].X;
						enemyBulletsRec[j].Y = enemyBulletsRec[j + 1].Y;
					}

					numRobotBullets--;
				}
			}

			totalEnemyCount = batEnemiesToSpawn - batEnemiesSpawned;

			if (totalEnemyCount <= 0 && batEnemiesCount <= 0)
			{
				downArrowRec.X = (int)downArrowLoc.X;
				downArrowRec.Y = (int)downArrowLoc.Y;

				if (mainCharJAnim[charDirection].destRec.Intersects(enemySpawnFloorsRec[DOWN]) || mainCharEAnim[charDirection].destRec.Intersects(enemySpawnFloorsRec[DOWN]))
				{
					currentRound++;

					if (batEnemiesToSpawn + 5 < MAX_BATS)
					{
						batEnemiesToSpawn = 20 + (5 * (currentRound - 1));
					}

					if (robotEnemiesToSpawn + 5 < MAX_ROBOTS && currentRound %2 == 0)
					{
						robotEnemiesToSpawn = (5 * (currentRound - 1));
					}

					for (int i = 0; i < playerBulletsCount; i++)
					{
						DeleteBullet(i);
					}

					playerFireRateTimer.ResetTimer(true);

					coffeeAnim.destRec.X = (int)HIDE_OBJECTS_LOCATION;
					coffeeAnim.destRec.Y = (int)HIDE_OBJECTS_LOCATION;
					isCoffeeInRoom = false;

					RandomRoomRockLayout();

					batEnemiesSpawned = 0;
					robotEnemiesSpawned = 0;
					mainCharLoc = roomCharacterStartLoc;

					randomUpgradeLeft = rng.Next(0, 99);
					randomUpgradeRight = rng.Next(0, 99);

					upgradeOptionChosen = false;

					for (int i = 0; i < 4; i++)
					{
						isUpgradeActive[i] = false;
						upgradesRec[i].X = (int)hideObjectsLoc.X;
						upgradesRec[i].Y = (int)hideObjectsLoc.Y;
					}

					gameState = UPGRADE;
				}
			}
			else
			{
				downArrowRec.X = (int)HIDE_OBJECTS_LOCATION;
				downArrowRec.Y = (int)HIDE_OBJECTS_LOCATION;
			}

			if (playerJHealth <= 0 && playerEHealth <= 0)
			{
				gameState = ENDGAME;
			}
		}

		private void UpdateUpgrade()
		{
			while (upgradeOptionChosen == false)
			{
				if (randomUpgradeLeft < 25)
				{
					upgradesRec[BOOTS].X = (int)upgrade1Loc.X;
					upgradesRec[BOOTS].Y = (int)upgrade1Loc.Y;
					isUpgradeActive[BOOTS] = true;
				}
				else if (randomUpgradeLeft < 50)
				{
					upgradesRec[CLOCK].X = (int)upgrade1Loc.X;
					upgradesRec[CLOCK].Y = (int)upgrade1Loc.Y;
					isUpgradeActive[CLOCK] = true;
				}
				else if (randomUpgradeLeft < 75)
				{
					upgradesRec[THREE_BULLETS].X = (int)upgrade1Loc.X;
					upgradesRec[THREE_BULLETS].Y = (int)upgrade1Loc.Y;
					isUpgradeActive[THREE_BULLETS] = true;
				}
				else
				{
					upgradesRec[SHIELD].X = (int)upgrade1Loc.X;
					upgradesRec[SHIELD].Y = (int)upgrade1Loc.Y;
					isUpgradeActive[SHIELD] = true;
				}

				if (randomUpgradeRight < 25 && isUpgradeActive[BOOTS] == false)
				{
					upgradesRec[BOOTS].X = (int)upgrade2Loc.X;
					upgradesRec[BOOTS].Y = (int)upgrade2Loc.Y;
					upgradeOptionChosen = true;
				}
				else if (randomUpgradeRight < 50 && isUpgradeActive[CLOCK] == false)
				{
					upgradesRec[CLOCK].X = (int)upgrade2Loc.X;
					upgradesRec[CLOCK].Y = (int)upgrade2Loc.Y;
					upgradeOptionChosen = true;
				}
				else if (randomUpgradeRight < 75 && isUpgradeActive[THREE_BULLETS] == false)
				{
					upgradesRec[THREE_BULLETS].X = (int)upgrade2Loc.X;
					upgradesRec[THREE_BULLETS].Y = (int)upgrade2Loc.Y;
					upgradeOptionChosen = true;
				}
				else if (isUpgradeActive[SHIELD] == false)
				{
					upgradesRec[SHIELD].X = (int)upgrade2Loc.X;
					upgradesRec[SHIELD].Y = (int)upgrade2Loc.Y;
					upgradeOptionChosen = true;
				}
				else
				{
					randomUpgradeRight = rng.Next(0, 99);
				}
			}

			if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton != ButtonState.Pressed)
			{
				if (upgradesRec[BOOTS].Contains(mouse.Position))
				{
					currentMaxSpeed++;
					maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
					gameState = GAME;
				}
				else if (upgradesRec[CLOCK].Contains(mouse.Position))
				{
					fireRateMultiplier *= 0.95f;
					gameState = GAME;
				}
				else if (upgradesRec[THREE_BULLETS].Contains(mouse.Position))
				{
					storedMultiShot += 10;
					gameState = GAME;
				}
				else if (upgradesRec[SHIELD].Contains(mouse.Position))
				{
					timesImmuneUpgraded++;
					playerImmunityTimer = new Timer(3000 + (timesImmuneUpgraded * 500), true);
					gameState = GAME;
				}
			}
		}

		private void UpdateEndGame()
		{
			menuBtn = menuBtnRec.Contains(mouse.Position);
			retryBtn = retryBtnRec.Contains(mouse.Position);

			if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton != ButtonState.Pressed)
			{
				if (retryBtnRec.Contains(mouse.Position))
				{
					gameState = PREGAME;
				}
				else if (menuBtnRec.Contains(mouse.Position))
				{
					gameState = MENU;
				}
			}
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.Black);

			// TODO: Add your drawing code here
			spriteBatch.Begin();
			switch (gameState)
			{
				case MENU:
					DrawMenu();
					break;
				case INSTRUCTIONS:
					DrawInstructions();
					break;
				case PREGAME:
					DrawPregame();
					break;
				case GAME:
					DrawGame();
					break;
				case UPGRADE:
					DrawUpgrade();
					break;
				case ENDGAME:
					DrawEndGame();
					break;
			}
			spriteBatch.End();

			base.Draw(gameTime);
		}

		private void DrawMenu()
		{
			spriteBatch.Draw(startImg[Convert.ToByte(startBtn)], startBtnRec, Color.White);
			spriteBatch.Draw(intsImg[Convert.ToByte(intsBtn)], intsBtnRec, Color.White);
		}

		private void DrawInstructions()
		{

		}

		private void DrawPregame()
		{

		}

		private void DrawGame()
		{
			spriteBatch.Draw(wallBkImg, wallBkRec, Color.White);
			spriteBatch.Draw(floorBkImg, floorBkRec, Color.White);

			for (int i = 0; i < 4; i++)
			{
				spriteBatch.Draw(floorBkImg, enemySpawnFloorsRec[i], Color.Gray);
			}

			if (charDistFromRockY < 0)
			{
				mainCharJAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				mainCharEAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);

				for (int i = 0; i < 20; i++)
				{
					spriteBatch.Draw(randomRocksImg[i], rocksRec[i], Color.White);
				}
			}
			else
			{
				for (int i = 0; i < 20; i++)
				{
					spriteBatch.Draw(randomRocksImg[i], rocksRec[i], Color.White);
				}

				mainCharJAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				mainCharEAnim[charDirection].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
			}

			spriteBatch.Draw(downArrowImg, downArrowRec, Color.White);

			for (int i = 0; i < playerBulletsCount; i++)
			{
				if (isBulletOfJ[i] == true)
				{
					spriteBatch.Draw(metalBulletImg, playerBulletsRec[i], Color.White);
				}
				else
				{
					spriteBatch.Draw(woodBulletImg, playerBulletsRec[i], Color.White);
				}
			}

			for (int i = 0; i < batEnemiesCount; i++)
			{
				batEnemyAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
			}

			for (int i = 0; i < robotEnemiesCount; i++)
			{
				if (robotDirections[i] == DOWN)
				{
					robotEnemyDownAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				}
				else if (robotDirections[i] == LEFT)
				{
					robotEnemyLeftAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				}
				else if (robotDirections[i] == RIGHT)
				{
					robotEnemyRightAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				}
				else if (robotDirections[i] == UP)
				{
					robotEnemyUpAnim[i].Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
				}
			}

			for (int i = 0; i < numRobotBullets; i++)
			{
				spriteBatch.Draw(enemyBulletImg, enemyBulletsRec[i], Color.White);
			}

			coffeeAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);

			if (playerJHealth <= 0)
			{
				spriteBatch.Draw(brokenHeartImg, heartJLoc, Color.White);
			}
			else
			{
				spriteBatch.Draw(heartImg, heartJLoc, Color.White);
				spriteBatch.DrawString(gameFont, Convert.ToString(playerJHealth), healthJLoc, Color.White);
			}

			if (playerEHealth <= 0)
			{
				spriteBatch.Draw(brokenHeartImg, heartELoc, Color.White);
			}
			else
			{
				spriteBatch.Draw(heartImg, heartELoc, Color.White);
				spriteBatch.DrawString(gameFont, Convert.ToString(playerEHealth), healthELoc, Color.White);
			}

			UICoffeeAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
			smokeTagAnim.Draw(spriteBatch, Color.White, Animation.FLIP_NONE);
		}

		private void DrawUpgrade()
		{
			for (int i = 0; i < 4; i++)
			{
				spriteBatch.Draw(upgradesImg[i], upgradesRec[i], Color.White);
			}
		}

		private void DrawEndGame()
		{
			spriteBatch.Draw(retryImg[Convert.ToByte(retryBtn)], retryBtnRec, Color.White);
			spriteBatch.Draw(menuImg[Convert.ToByte(menuBtn)], menuBtnRec, Color.White);
		}

		private void PlayerShooting()
		{
			playerBulletAngle = (float)Math.Atan((mouse.Y - mainCharCenterLoc.Y) / ((mouse.X - mainCharCenterLoc.X)));

			if (isJActive == true)
			{
				isBulletOfJ[playerBulletsCount] = true;
			}
			else
			{
				isBulletOfJ[playerBulletsCount] = false;
			}

			if (mouse.X < mainCharCenterLoc.X)
			{
				playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Cos(playerBulletAngle + (currentMultiShotAngle * (Math.PI / 180)));
				playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * -(float)Math.Sin(playerBulletAngle + (currentMultiShotAngle * (Math.PI / 180)));
			}
			else
			{
				playerBulletSpeedX[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Cos(playerBulletAngle + (currentMultiShotAngle * (Math.PI / 180)));
				playerBulletSpeedY[playerBulletsCount] = BASE_BULLET_SPEED * (float)Math.Sin(playerBulletAngle + (currentMultiShotAngle * (Math.PI / 180)));
			}

			playerBulletsLoc[playerBulletsCount] = mainCharCenterLoc;
			playerBulletsCount++;

			playerFireRateTimer.ResetTimer(true);
		}

		private void BatMoving(int batNumber)
		{
			if (mainCharCenterLoc.X - batEnemyAnim[batNumber].destRec.Center.X < -10)
			{
				batEnemiesLoc[batNumber].X -= BASE_BAT_SPEED;
			}
			else if (mainCharCenterLoc.X - batEnemyAnim[batNumber].destRec.Center.X > 10)
			{
				batEnemiesLoc[batNumber].X += BASE_BAT_SPEED;
			}

			if (mainCharCenterLoc.Y - batEnemyAnim[batNumber].destRec.Center.Y < -10)
			{
				batEnemiesLoc[batNumber].Y -= BASE_BAT_SPEED;
			}
			else if (mainCharCenterLoc.Y - batEnemyAnim[batNumber].destRec.Center.Y > 10)
			{
				batEnemiesLoc[batNumber].Y += BASE_BAT_SPEED;
			}

			batEnemyAnim[batNumber].destRec.X = (int)batEnemiesLoc[batNumber].X;
			batEnemyAnim[batNumber].destRec.Y = (int)batEnemiesLoc[batNumber].Y;
		}

		private Vector2 EnemyDeath(Vector2[] enemyLoc, int bullet, int enemy, int enemyCount)
		{
			if (rng.Next(0, 99) <= 24 && isCoffeeInRoom == false)
			{
				coffeeAnim.destRec.X = (int)enemyLoc[enemy].X;
				coffeeAnim.destRec.Y = (int)enemyLoc[enemy].Y;
				isCoffeeInRoom = true;
			}

			for (int j = enemy; j < enemyCount; j++)
			{
				enemyLoc[j].X = enemyLoc[j + 1].X;
				enemyLoc[j].Y = enemyLoc[j + 1].Y;
			}

			if (isBulletOfJ[bullet] == true)
			{
				DeleteBullet(bullet);
			}

			charEPierceTimer.ResetTimer(true);

			return enemyLoc[enemy];
		}

		private void DeleteBullet (int bullet)
		{
			for (int i = bullet; i < playerBulletsCount; i++)
			{
				isBulletOfJ[i] = isBulletOfJ[i + 1];
				playerBulletSpeedX[i] = playerBulletSpeedX[i + 1];
				playerBulletSpeedY[i] = playerBulletSpeedY[i + 1];
				playerBulletsLoc[i].X = playerBulletsLoc[i + 1].X;
				playerBulletsLoc[i].Y = playerBulletsLoc[i + 1].Y;
				playerBulletsRec[i].X = (int)playerBulletsLoc[i].X;
				playerBulletsRec[i].Y = (int)playerBulletsLoc[i].Y;
			}

			playerBulletsCount--;
		}

		private Vector2 EnemySpawning()
		{
			randomEnemySpawnDirection = rng.Next(0, 100);

			if (randomEnemySpawnDirection <= 24)
			{
				return enemySpawnsLoc[DOWN];
			}
			else if (randomEnemySpawnDirection <= 49)
			{
				return enemySpawnsLoc[LEFT];
			}
			else if (randomEnemySpawnDirection <= 74)
			{
				return enemySpawnsLoc[RIGHT];
			}
			else
			{
				return enemySpawnsLoc[UP];
			}
		}

		private void CoffeeActivation()
		{
			if (coffeeEffectTimer.IsInactive())
			{
				coffeeEffectTimer.Activate();
				currentMaxSpeed += 1;
			}
			else
			{
				coffeeEffectTimer.ResetTimer(true);
			}

			maxDiagonalSpeed = (float)Math.Sqrt(currentMaxSpeed);
		}

		private void RandomRoomRockLayout()
		{
			for (int i = 0; i < 20; i++)
			{
				rocksRec[i].X = (int)HIDE_OBJECTS_LOCATION;
				rocksRec[i].Y = (int)HIDE_OBJECTS_LOCATION;
			}

			int randomRoom = rng.Next(0, 100);

			if (randomRoom <= 19)
			{
				for (int i = 0; i < roomType1X.Length; i++)
				{
					rocksRec[i].X = (int)roomType1X[i];
					rocksRec[i].Y = (int)roomType1Y[i];
					numRocks = (byte)roomType1X.Length;
				}
			}
			else if (randomRoom <= 39)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else if (randomRoom <= 59)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else if (randomRoom <= 79)
			{
				for (int i = 0; i < roomType2X.Length; i++)
				{
					rocksRec[i].X = (int)roomType2X[i];
					rocksRec[i].Y = (int)roomType2Y[i];
					numRocks = (byte)roomType2X.Length;
				}
			}
			else
			{
				for (int i = 0; i < roomType1X.Length; i++)
				{
					rocksRec[i].X = (int)roomType1X[i];
					rocksRec[i].Y = (int)roomType1Y[i];
					numRocks = (byte)roomType1X.Length;
				}
			}
		}

		private void RandomizeRockTypes(int currentRock)
		{
			int randomRockType = rng.Next(0, 99);

			if (randomRockType <= 32)
			{
				randomRocksImg[currentRock] = rock1Img;
			}
			else if (randomRockType <= 65)
			{
				randomRocksImg[currentRock] = rock2Img;
			}
			else
			{
				randomRocksImg[currentRock] = rock3Img;
			}
		}

		/*private Animation RockCollision (Animation currentAnim)
		{
			

			return currentAnim;
		}*/
	}
}
